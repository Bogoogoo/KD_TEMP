-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.daily_report_for_sales_gallery_detail 結構
DROP TABLE IF EXISTS `daily_report_for_sales_gallery_detail`;
CREATE TABLE IF NOT EXISTS `daily_report_for_sales_gallery_detail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `crm_id` bigint NOT NULL COMMENT 'CRM_ID',
  `daily_report_for_sales_id` int NOT NULL COMMENT '工作日報管理-每日報表(業務)ID',
  `entity_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '業務類型',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '展示館參訪記錄名稱',
  `customItem29__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '展示館區域',
  `report_date` date NOT NULL COMMENT '預約參訪日期/日報日期',
  `user_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '接待人員1-姓名',
  `employee_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '接待人員1-員工編號',
  `customItem83__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公司型態1',
  `company_name1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公司名稱1',
  `customItem42__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '連絡人1',
  `customItem65__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '職務類別1',
  `customItem8__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '參訪職務類別',
  `customItem39__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '參訪品項',
  `customItem28__c` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '參訪記錄',
  `customItem92__c` text COLLATE utf8mb4_unicode_ci COMMENT '內部備註',
  `customItem38__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '工地',
  `customItem37__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '工期',
  `customItem21__c` time DEFAULT NULL COMMENT '開始接待時間',
  `customItem22__c` time DEFAULT NULL COMMENT '結束接待時間',
  `customItem68__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '是否需下交辦',
  `customItem77__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '是否講解K大',
  `customItem81__c` decimal(5,0) DEFAULT NULL COMMENT '講解分鐘數',
  `customItem78__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '未K大原因',
  `customItem93__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '是否觀看公司團隊神影片',
  `customItem94__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '未觀看影片原因',
  `customItem100__c` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '五星好評活動禮券(張數)',
  `come_from` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TW' COMMENT '從哪個CRM來：TW、CN',
  `is_show` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`),
  KEY `idx_daily_report_for_sales_id` (`daily_report_for_sales_id`),
  KEY `idx_report_date` (`report_date`),
  KEY `idx_is_show` (`is_show`),
  KEY `idx_report_date_is_show` (`report_date`,`is_show`)
) ENGINE=InnoDB AUTO_INCREMENT=2050 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作日報管理-每日報表(業務)-展示館參訪記錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
