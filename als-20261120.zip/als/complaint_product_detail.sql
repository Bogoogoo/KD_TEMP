-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_product_detail 結構
DROP TABLE IF EXISTS `complaint_product_detail`;
CREATE TABLE IF NOT EXISTS `complaint_product_detail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '明細ID',
  `complaint_id` int unsigned NOT NULL COMMENT '關聯 complaint.id',
  `product_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '產品類型',
  `product_type_new` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新增產品類型',
  `defect_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '瑕疵類型',
  `defect_type_new` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新增瑕疵類型',
  `defect_judgment` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '判斷瑕疵狀況',
  `complaint_grade` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'X' COMMENT '此產品品項分級：A/B/C/D/X',
  `responsible_unit` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '此產品品項權責單位',
  `responsible_unit_handler` int DEFAULT NULL COMMENT '此產品品項權責單位處理人員 ALS user.id',
  `type_analysis` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '類型分析',
  `type_analysis2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '類型分析2',
  `confidence` json DEFAULT NULL COMMENT '此產品品項 AI 信心度 JSON，如 {"complaint_grade":0.5}',
  `order_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '訂單編號',
  `item_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品號',
  `batch_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '批次',
  `product_qc_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '產品QC碼',
  `ship_date` date DEFAULT NULL COMMENT '出貨日期',
  `quantity` decimal(10,2) DEFAULT NULL COMMENT '數量',
  `source` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '明細來源：AI分析／權責判斷',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否為生效明細：1=生效/0=停用',
  `created_by` int NOT NULL COMMENT '建立者ID',
  `updated_by` int DEFAULT NULL COMMENT '更新者ID',
  `created_at` datetime NOT NULL COMMENT '建立時間（建立時由後端帶入）',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`),
  KEY `idx_complaint_product_detail_complaint_active` (`complaint_id`,`is_active`),
  KEY `idx_complaint_product_detail_product_type` (`product_type`),
  KEY `idx_complaint_product_detail_item_code` (`item_code`),
  KEY `idx_complaint_product_detail_batch_code` (`batch_code`)
) ENGINE=InnoDB AUTO_INCREMENT=448 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴產品明細';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
