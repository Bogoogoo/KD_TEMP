-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.daily_report_sales 結構
DROP TABLE IF EXISTS `daily_report_sales`;
CREATE TABLE IF NOT EXISTS `daily_report_sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_org_b_id` int DEFAULT NULL COMMENT '業務區域ID',
  `off_time` time DEFAULT NULL COMMENT '下班時間',
  `suggest` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '反映與建議',
  `reading_plan` text COLLATE utf8mb4_unicode_ci COMMENT '共讀計畫',
  `renovation_warrior` text COLLATE utf8mb4_unicode_ci COMMENT '主管裝修共讀',
  `education_training` text COLLATE utf8mb4_unicode_ci COMMENT '教育訓練心得 JSON {"courseTitle":"...","courseReflection":"..."}',
  `quarterly_meeting_reflection` text COLLATE utf8mb4_unicode_ci COMMENT '季會心得內容（HTML，全體填寫）；NULL 或空字串代表未填寫',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint DEFAULT NULL COMMENT '草稿(0), 繳交(1)',
  `report_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '每日回報',
  `routine_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '例行事項',
  `report_date` date DEFAULT NULL COMMENT '日報日期',
  `instruct_status` tinyint DEFAULT NULL COMMENT '批示狀態',
  `is_show` tinyint DEFAULT '1' COMMENT '是否顯示',
  `assign` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '交辦覆誦',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_user_show_date` (`user_id`,`is_show`,`report_date`)
) ENGINE=InnoDB AUTO_INCREMENT=56429 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='業管日報';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
