-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.permission_management_trainee 結構
DROP TABLE IF EXISTS `permission_management_trainee`;
CREATE TABLE IF NOT EXISTS `permission_management_trainee` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ch_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_id` int NOT NULL,
  `is_show` tinyint NOT NULL,
  `sort` int DEFAULT NULL,
  `creator_id` int NOT NULL,
  `updator_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 正在傾印表格  als.permission_management_trainee 的資料：~3 rows (近似值)
DELETE FROM `permission_management_trainee`;
INSERT INTO `permission_management_trainee` (`id`, `ch_name`, `language_id`, `is_show`, `sort`, `creator_id`, `updator_id`, `created_at`, `updated_at`) VALUES
	(1, '儲備幹部', 910, 1, 1, 1, 1, '2025-02-19 07:35:43', '2025-12-23 08:21:15'),
	(2, 'MA儲幹', 911, 1, 2, 1, NULL, '2025-02-19 07:35:43', '2025-02-19 07:35:43'),
	(3, '儲備主管', 938, 1, 0, 5461, 5461, '2026-09-08 06:09:59', '2026-09-08 06:28:55');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
