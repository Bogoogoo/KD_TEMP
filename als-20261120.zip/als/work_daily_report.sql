-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.work_daily_report 結構
DROP TABLE IF EXISTS `work_daily_report`;
CREATE TABLE IF NOT EXISTS `work_daily_report` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `user_id` int NOT NULL COMMENT '使用者流水號',
  `organization_a_id` smallint DEFAULT NULL COMMENT '組別流水號',
  `daily_report_category_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '組別項目代號json',
  `today_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '今日成果',
  `amount` smallint DEFAULT NULL COMMENT '數量',
  `use_minute` smallint DEFAULT NULL COMMENT '耗時(分)',
  `get_off_work` time DEFAULT NULL COMMENT '下班時間',
  `suggestion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '反應與建議',
  `tomorrow_plan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '明日計劃',
  `today_result_files` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '今日成果檔案',
  `suggestion_files` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '反應與建議檔案',
  `tomorrow_plan_files` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '明日計劃檔案',
  `work_matters` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '交辦覆誦',
  `proposal` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '改善提案',
  `out_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公出時間',
  `overtime_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '加班成果(人事招募、人事薪資、銷管)',
  `average_minute` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '平均分鐘(人事招募)',
  `standard` tinyint DEFAULT NULL COMMENT '標準分鐘(人事薪資)',
  `difference` tinyint DEFAULT NULL COMMENT '差異分鐘(人事薪資)',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否顯示',
  `created_at` datetime NOT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `organization_b_id` (`organization_a_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作回報管理 - 每日工作回報';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
