-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_process_template_stage 結構
DROP TABLE IF EXISTS `complaint_process_template_stage`;
CREATE TABLE IF NOT EXISTS `complaint_process_template_stage` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '模板關卡ID',
  `complaint_process_template_id` int unsigned NOT NULL COMMENT '關聯流程模板主表',
  `stage` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '關卡名稱，來源為 complaint_options stage',
  `stage_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'main' COMMENT '關卡類型：main／custom_main／cosign',
  `action` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '關卡動作',
  `next_stage` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '下一關卡名稱',
  `assigned_to` int unsigned DEFAULT NULL COMMENT '預設指定處理人，動態處理人可為 NULL',
  `assigned_by` int unsigned DEFAULT NULL COMMENT '預設指派人',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '未執行' COMMENT '模板初始狀態',
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '關卡說明',
  `next_assigned_to` int unsigned DEFAULT NULL COMMENT '下一關預設處理人',
  `assigned_at` datetime DEFAULT NULL COMMENT '預設指派時間',
  `completed_at` datetime DEFAULT NULL COMMENT '預設完成時間',
  `deadline_at` datetime DEFAULT NULL COMMENT '預設期限',
  `sort_order` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程排序，例如 01、02、03',
  `parent_id` int unsigned DEFAULT NULL COMMENT '父關卡 template_stage.id，NULL=主幹關卡',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否啟用：1=啟用/0=停用',
  `created_by` int NOT NULL COMMENT '建立者ID',
  `updated_by` int DEFAULT NULL COMMENT '更新者ID',
  `created_at` datetime NOT NULL COMMENT '建立時間（建立時由後端帶入）',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`),
  KEY `idx_cpts_template_active_sort` (`complaint_process_template_id`,`is_active`,`sort_order`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴預設流程模板關卡副表';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
