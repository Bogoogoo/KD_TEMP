-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 移除臨時表格，並建立最終檢視結構
DROP TABLE IF EXISTS `v_complaint_handler_sync`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `v_complaint_handler_sync` AS select distinct `c`.`id` AS `id`,`c`.`complaint_code` AS `complaint_code`,`c`.`responsible_unit` AS `responsible_unit`,`c`.`responsible_unit_handler` AS `responsible_unit_handler`,`c`.`updated_at` AS `updated_at`,`cpl`.`assigned_to` AS `assigned_to`,`cpl`.`status` AS `log_status`,`m`.`handler_user_id` AS `mapping_handler_id` from ((`complaint` `c` join `complaint_process_log` `cpl` on((`c`.`id` = `cpl`.`complaint_id`))) left join `complaint_responsible_unit_mapping` `m` on(((`m`.`type` = '權責單位') and (`m`.`unit_name` = `c`.`responsible_unit`) and (`m`.`id` = (select min(`m2`.`id`) from `complaint_responsible_unit_mapping` `m2` where ((`m2`.`type` = '權責單位') and (`m2`.`unit_name` = `c`.`responsible_unit`))))))) where ((`c`.`responsible_unit` is not null) and (`c`.`responsible_unit` <> '') and (`c`.`responsible_unit_handler` is null) and (`cpl`.`stage` = '權責回應') and (`cpl`.`deleted_at` is null) and ((`cpl`.`action` is null) or (`cpl`.`action` <> '加簽')) and (`cpl`.`assigned_to` is not null) and (`m`.`handler_user_id` is not null))
;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
