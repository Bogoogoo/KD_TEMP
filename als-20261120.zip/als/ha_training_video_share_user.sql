-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.ha_training_video_share_user 結構
DROP TABLE IF EXISTS `ha_training_video_share_user`;
CREATE TABLE IF NOT EXISTS `ha_training_video_share_user` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int unsigned NOT NULL COMMENT '教育訓練影片任務 ID',
  `user_id` int NOT NULL COMMENT '分享使用者 ID',
  `is_edit` tinyint NOT NULL DEFAULT '0' COMMENT '權限角色(0:僅查看, 1:可編輯)',
  `is_show` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否顯示',
  `creator_id` int unsigned NOT NULL COMMENT '建立者ID',
  `updator_id` int unsigned DEFAULT NULL COMMENT '更新者ID',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ha_training_video_share_user_task_id_index` (`task_id`),
  KEY `ha_training_video_share_user_user_id_index` (`user_id`),
  KEY `ha_training_video_share_user_is_show_index` (`is_show`),
  KEY `ha_training_video_share_user_task_id_is_show_index` (`task_id`,`is_show`),
  KEY `idx_task_user_is_show` (`task_id`,`user_id`,`is_show`),
  CONSTRAINT `ha_training_video_share_user_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `ha_training_video_tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='教育訓練影片-分享使用者清單';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
