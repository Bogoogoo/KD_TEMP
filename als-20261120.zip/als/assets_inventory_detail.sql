-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.assets_inventory_detail 結構
DROP TABLE IF EXISTS `assets_inventory_detail`;
CREATE TABLE IF NOT EXISTS `assets_inventory_detail` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `assets_pk` int NOT NULL COMMENT '資產主表流水號',
  `assets_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '資產編號',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '資產編號',
  `type` int NOT NULL COMMENT '1固定資產 2列管資產',
  `department_id` int NOT NULL COMMENT '部門編號',
  `location_id` int NOT NULL COMMENT '資產位置',
  `category_id` int NOT NULL COMMENT '資產類別 old  type_id',
  `keeper_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '保管人姓名',
  `new_keeper_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新保管人姓名',
  `money` int NOT NULL COMMENT '資產金額',
  `quantity` int NOT NULL COMMENT '實盤數 = 盤點實際數(實際數量)',
  `get_date` date NOT NULL COMMENT '取得日期',
  `vendor` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '廠商',
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '備註',
  `inventory_id` int NOT NULL COMMENT '盤點編號 assets_inventory',
  `is_inventory` int NOT NULL DEFAULT '0' COMMENT '盤點狀態 1:已盤點 0:尚未盤點',
  `updater_id` int DEFAULT NULL COMMENT '最後盤點者',
  `created_at` datetime NOT NULL COMMENT '建立時間',
  `updated_at` datetime NOT NULL COMMENT '修改時間',
  `is_show` int NOT NULL DEFAULT '1' COMMENT '是否顯示 (1 顯示 0不顯示)',
  `updated_location_id` int DEFAULT NULL COMMENT '新資產位置',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
