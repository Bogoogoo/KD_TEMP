-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.ha_dialogue_training_client_role 結構
DROP TABLE IF EXISTS `ha_dialogue_training_client_role`;
CREATE TABLE IF NOT EXISTS `ha_dialogue_training_client_role` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `audit_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '稽核類型: 電訪(Mr.K-Call)',
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '客戶類型: 討厭型(Angry), 客訴型(Complainer), 忙碌型(BusyMan), 友善型(Friendly), 無效型(Invalid)',
  `language` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'zh-TW' COMMENT '語系: 台灣(zh-TW)',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '顯示名稱',
  `description` text COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `prompt` json NOT NULL COMMENT 'System Prompt',
  `is_show` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否顯示(顯示:1, 不顯示:0)',
  `creator_id` int unsigned NOT NULL DEFAULT '1' COMMENT '建立者ID',
  `updator_id` int unsigned DEFAULT NULL COMMENT '更新者ID',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立時間',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`),
  KEY `atl_index` (`audit_type`,`type`,`language`),
  KEY `ha_dialogue_training_client_role_is_show_index` (`is_show`),
  KEY `ha_dialogue_training_client_role_creator_id_index` (`creator_id`),
  KEY `ha_dialogue_training_client_role_updator_id_index` (`updator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='會議助理-對話訓練-客戶類型';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
