-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.webhook_meeting_config 結構
DROP TABLE IF EXISTS `webhook_meeting_config`;
CREATE TABLE IF NOT EXISTS `webhook_meeting_config` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '國家',
  `sequence_minutes_with_workday` tinyint NOT NULL DEFAULT '10' COMMENT '平日-每多少分鐘為一個場次',
  `login_start_minutes_with_workday` tinyint NOT NULL DEFAULT '10' COMMENT '平日-登入會議室開始時間-扣掉多少分鐘',
  `login_end_minutes_with_workday` tinyint NOT NULL DEFAULT '0' COMMENT '平日-登入會議室結束時間-加上多少分鐘',
  `limit_minutes_with_workday` tinyint NOT NULL DEFAULT '60' COMMENT '平日-會議長度為：多少分鐘',
  `limit_time_with_workday` tinyint NOT NULL DEFAULT '19' COMMENT '平日-會議室服務結束時間',
  `sequence_minutes_with_workday_after_work` tinyint DEFAULT NULL COMMENT '平日-下班後每多少分鐘為一個場次',
  `login_start_minutes_with_workday_after_work` tinyint DEFAULT NULL COMMENT '平日-下班後登入會議室開始時間-扣掉多少分鐘',
  `login_end_minutes_with_workday_after_work` tinyint DEFAULT NULL COMMENT '平日-下班後登入會議室結束時間-加上多少分鐘',
  `limit_minutes_with_workday_after_work` tinyint DEFAULT NULL COMMENT '平日-下班後會議長度為：多少分鐘',
  `sequence_minutes_with_saturday` tinyint NOT NULL DEFAULT '65' COMMENT '星期六-每多少分鐘為一個場次',
  `login_start_minutes_with_saturday` tinyint NOT NULL DEFAULT '5' COMMENT '星期六-登入會議室開始時間-扣掉多少分鐘',
  `login_end_minutes_with_saturday` tinyint NOT NULL DEFAULT '65' COMMENT '星期六-登入會議室結束時間-加上多少分鐘',
  `limit_minutes_with_saturday` tinyint NOT NULL DEFAULT '65' COMMENT '星期六-會議長度為：多少分鐘',
  `limit_time_with_saturday` tinyint NOT NULL DEFAULT '14' COMMENT '星期六-會議室服務結束時間',
  `effective_date` date NOT NULL COMMENT '生效日期',
  `created_by` int DEFAULT NULL COMMENT '建立人員',
  `updated_by` int DEFAULT NULL COMMENT '更新人員',
  `deleted_by` int DEFAULT NULL COMMENT '刪除人員',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日期',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '刪除日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Webhook-K大會議設定';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
