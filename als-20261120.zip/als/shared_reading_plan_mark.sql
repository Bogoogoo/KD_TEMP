-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.shared_reading_plan_mark 結構
DROP TABLE IF EXISTS `shared_reading_plan_mark`;
CREATE TABLE IF NOT EXISTS `shared_reading_plan_mark` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `report_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '日報類型(一般日報[daily_report], 專案日報[project_report], 業務日報[crm_report])',
  `category` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'shared_reading' COMMENT '類別(shared_reading=共讀計畫, renovation_warrior=裝修小武郎)',
  `report_id` int NOT NULL COMMENT '日報ID',
  `user_id` int NOT NULL COMMENT '標註人員ID',
  `is_mark` tinyint NOT NULL COMMENT '是否標註(是[1], 否[0])',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立時間',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`),
  UNIQUE KEY `srpm_report_id_type_user_category_unique` (`report_id`,`report_type`,`user_id`,`category`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='共讀計畫標註';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
