-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 移除臨時表格，並建立最終檢視結構
DROP TABLE IF EXISTS `shared_reading_result`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `shared_reading_result` AS select `shared_reading_users`.`id` AS `id`,`shared_reading_users`.`name` AS `name`,`shared_reading_users`.`employee_id` AS `employee_id`,`shared_reading_users`.`title` AS `title`,`shared_reading_users`.`department` AS `department`,`shared_reading_users`.`hrs_code` AS `hrs_code`,ifnull((select cast(`shared_reading_reports`.`report_date` as char charset utf8mb4) from `shared_reading_reports` where (`shared_reading_reports`.`user_id` = `shared_reading_users`.`id`) order by `shared_reading_reports`.`report_date`,`shared_reading_reports`.`id` limit 1),'NaN') AS `report_date`,ifnull((select `shared_reading_reports`.`report_type` from `shared_reading_reports` where (`shared_reading_reports`.`user_id` = `shared_reading_users`.`id`) order by `shared_reading_reports`.`report_date`,`shared_reading_reports`.`id` limit 1),NULL) AS `report_type`,ifnull((select trim(regexp_replace(regexp_replace(`shared_reading_reports`.`reading_plan`,'<[^>]*>',''),'[\r\n]+',' ')) AS `reading_plan` from `shared_reading_reports` where (`shared_reading_reports`.`user_id` = `shared_reading_users`.`id`) order by `shared_reading_reports`.`report_date`,`shared_reading_reports`.`id` limit 1),NULL) AS `reading_plan` from `shared_reading_users`
;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
