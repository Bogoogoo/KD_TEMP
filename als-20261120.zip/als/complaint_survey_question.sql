-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_survey_question 結構
DROP TABLE IF EXISTS `complaint_survey_question`;
CREATE TABLE IF NOT EXISTS `complaint_survey_question` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '題目ID',
  `complaint_survey_type_id` int unsigned NOT NULL COMMENT '關聯 complaint_survey_type.id',
  `dimension` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '面向，例如業務／司機／工務／服務／產品／建議',
  `question` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '題目文字',
  `input_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '作答型別：single=單選/multiple=多選/text=文字',
  `answer_options` json DEFAULT NULL COMMENT '回答選項（單選／多選使用），格式 [{"value":1,"label":"..."}]',
  `follow_up_options` json DEFAULT NULL COMMENT '需業務關心後續的選項值陣列，例如 [1,2]',
  `in_input_required` tinyint NOT NULL DEFAULT '0' COMMENT '是否必填：1=必填/0=非必填',
  `sort_order` int NOT NULL DEFAULT '0' COMMENT '題目排序',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否啟用：1=啟用/0=停用',
  `created_by` int DEFAULT NULL COMMENT '建立者 user.id',
  `updated_by` int DEFAULT NULL COMMENT '更新者 user.id',
  `created_at` datetime DEFAULT NULL COMMENT '建立時間（建立時由後端帶入）',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間（DB 維護 CURRENT_TIMESTAMP）',
  PRIMARY KEY (`id`),
  KEY `idx_survey_question_type_active` (`complaint_survey_type_id`,`is_active`),
  KEY `idx_survey_question_sort` (`complaint_survey_type_id`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴滿意度問卷題目';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
