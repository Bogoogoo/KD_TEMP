-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.fileserver_audit_logs 結構
DROP TABLE IF EXISTS `fileserver_audit_logs`;
CREATE TABLE IF NOT EXISTS `fileserver_audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `security_identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_created` datetime NOT NULL,
  `object_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_source` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '來源檔案名稱',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fileserver_audit_logs_account_name_time_created_index` (`account_name`,`time_created`),
  KEY `fileserver_audit_logs_security_identifier_time_created_index` (`security_identifier`,`time_created`),
  KEY `fileserver_audit_logs_file_source_created_at_index` (`file_source`,`created_at`),
  KEY `fileserver_audit_logs_security_identifier_index` (`security_identifier`),
  KEY `fileserver_audit_logs_account_name_index` (`account_name`),
  KEY `fileserver_audit_logs_time_created_index` (`time_created`)
) ENGINE=InnoDB AUTO_INCREMENT=4603 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='webhook-queue-server - 紀錄抓取fileserver log';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
