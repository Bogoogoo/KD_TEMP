-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.opm_sample_delivery 結構
DROP TABLE IF EXISTS `opm_sample_delivery`;
CREATE TABLE IF NOT EXISTS `opm_sample_delivery` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `organization_b_id` int NOT NULL DEFAULT '0' COMMENT '組織B區ID(分公司)',
  `organization_c_id` int DEFAULT '0' COMMENT '組織C區ID(業績代碼)',
  `creator_id` int NOT NULL DEFAULT '0' COMMENT '填單人ID',
  `updater_id` int NOT NULL COMMENT '最後修改人員ID',
  `remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '備註',
  `item_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '項目名稱',
  `receiver_of_company` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '收件公司',
  `recipient` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '收件人',
  `receiver_of_phone` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '收件手機',
  `receiver_of_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0' COMMENT '收件地址',
  `warehouse_id` int NOT NULL DEFAULT '0' COMMENT '倉庫流水號',
  `delivery_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '快遞單號',
  `customer_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客戶類別',
  `specification_exception` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '發放異常說明',
  `is_record` tinyint NOT NULL DEFAULT '0' COMMENT '是否登打追蹤紀錄',
  `is_send` tinyint NOT NULL DEFAULT '0' COMMENT '是否發出',
  `created_at` datetime NOT NULL COMMENT '創建日期',
  `updated_at` datetime NOT NULL COMMENT '更新日期',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `organization_b_id` (`organization_b_id`) USING BTREE,
  KEY `organization_c_id` (`organization_c_id`) USING BTREE,
  KEY `creator_id` (`creator_id`) USING BTREE,
  KEY `updater_id` (`updater_id`) USING BTREE,
  KEY `warehouse_id` (`warehouse_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='倉庫快遞';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
