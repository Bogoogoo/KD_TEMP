-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_type_detail 結構
DROP TABLE IF EXISTS `complaint_type_detail`;
CREATE TABLE IF NOT EXISTS `complaint_type_detail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '明細ID',
  `complaint_id` int unsigned NOT NULL COMMENT '關聯 complaint.id',
  `service_category` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服務需求分類（此客訴類型所屬服務分類）',
  `service_category_new` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新增服務需求分類',
  `complaint_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客訴類型（新服務分類 only 時可為 NULL，改由 complaint_type_new 表示）',
  `complaint_type_new` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新增客訴類型',
  `complaint_grade` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'X' COMMENT '此客訴類型分級：A/B/C/D/X',
  `responsible_unit` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '此客訴類型權責單位',
  `responsible_unit_handler` int DEFAULT NULL COMMENT '此客訴類型權責單位處理人員 ALS user.id',
  `type_analysis` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '此客訴類型類型分析',
  `type_analysis2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '此客訴類型類型分析2',
  `confidence` json DEFAULT NULL COMMENT '此客訴類型 AI 信心度 JSON，如 {"complaint_grade":0.5}',
  `source` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '明細來源：AI分析／權責判斷',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否為生效明細：1=生效/0=停用',
  `created_by` int NOT NULL COMMENT '建立者ID',
  `updated_by` int DEFAULT NULL COMMENT '更新者ID',
  `created_at` datetime NOT NULL COMMENT '建立時間（建立時由後端帶入）',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`),
  KEY `idx_complaint_type_detail_complaint_active` (`complaint_id`,`is_active`),
  KEY `idx_complaint_type_detail_type` (`complaint_type`)
) ENGINE=InnoDB AUTO_INCREMENT=1039 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴類型明細';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
