-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.daily_report_accesses_fix 結構
DROP TABLE IF EXISTS `daily_report_accesses_fix`;
CREATE TABLE IF NOT EXISTS `daily_report_accesses_fix` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `user_id` int NOT NULL COMMENT '被批示者',
  `assign_user_id` int NOT NULL COMMENT '批示者',
  `report_date` date DEFAULT NULL COMMENT '工作日報日期(daily_report_accesses)',
  `report_date_type_1_from_assign` date DEFAULT NULL COMMENT '工作日報日期(從 daily_report_assign + daily_reports 來)',
  `report_date_type_2_from_assign` date DEFAULT NULL COMMENT '工作日報日期(從 daily_report_assign + daily_report_sales 來)',
  `report_date_type_3_from_assign` date DEFAULT NULL COMMENT '工作日報日期(從 daily_report_assign + daily_report_month_files)',
  `report_date_type_1_from_check` date DEFAULT NULL COMMENT '工作日報日期(從 daily_report_check + daily_reports 來)',
  `report_date_type_2_from_check` date DEFAULT NULL COMMENT '工作日報日期(從 daily_report_check + daily_report_sales 來)',
  `report_date_type_3_from_check` date DEFAULT NULL COMMENT '工作日報日期(從 daily_report_check + daily_report_month_files)',
  `min_report_date` date DEFAULT NULL COMMENT '最早工作日報日期',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建立日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
