-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  程序 als.CleanDuplicateReportChecks 結構
DROP PROCEDURE IF EXISTS `CleanDuplicateReportChecks`;
DELIMITER //
CREATE PROCEDURE `CleanDuplicateReportChecks`()
BEGIN
    -- 1. 宣告錯誤處理，若發生異常則回滾
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;

    -- 2. 建立臨時表存放需要被移除的 ID
    -- 使用 ROW_NUMBER() 標記重複資料，rn > 1 的就是需要移動/刪除的
    CREATE TEMPORARY TABLE IF NOT EXISTS tmp_duplicate_ids AS
    SELECT id
    FROM (
        SELECT id,
               ROW_NUMBER() OVER (
                   PARTITION BY parent_id, parent_type, user_id 
                   ORDER BY is_read DESC, created_at ASC, id ASC
               ) as rn
        FROM daily_report_checks
    ) t
    WHERE rn > 1;

    -- 3. 檢查是否有重複資料需要處理
    IF (SELECT COUNT(*) FROM tmp_duplicate_ids) > 0 THEN
        
        -- 4. 將重複資料複製到備份表
        INSERT INTO daily_report_checks_delete (id, parent_id, parent_type, user_id, is_read, created_at, updated_at)
        SELECT id, parent_id, parent_type, user_id, is_read, created_at, updated_at
        FROM daily_report_checks
        WHERE id IN (SELECT id FROM tmp_duplicate_ids);

        -- 5. 從原表刪除重複資料
        DELETE FROM daily_report_checks
        WHERE id IN (SELECT id FROM tmp_duplicate_ids);
        
    END IF;

    -- 6. 清理臨時表並提交
    DROP TEMPORARY TABLE IF EXISTS tmp_duplicate_ids;
    
    COMMIT;
END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
