-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.ha_training_video_tasks 結構
DROP TABLE IF EXISTS `ha_training_video_tasks`;
CREATE TABLE IF NOT EXISTS `ha_training_video_tasks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'uploading',
  `original_filename` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_path` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `converted_path` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio_path` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `output_path` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_seconds` int DEFAULT NULL,
  `voice_gender` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_transcript` text COLLATE utf8mb4_unicode_ci,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `progress_percent` int NOT NULL DEFAULT '0',
  `created_id` int NOT NULL COMMENT '建立者 ID',
  `updated_id` int DEFAULT NULL COMMENT '更新者 ID',
  `is_show` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否顯示',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ha_training_video_tasks_status_index` (`status`),
  KEY `ha_training_video_tasks_created_id_index` (`created_id`),
  KEY `ha_training_video_tasks_is_show_index` (`is_show`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='教育訓練影片-任務表';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
