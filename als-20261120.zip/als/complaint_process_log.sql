-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_process_log 結構
DROP TABLE IF EXISTS `complaint_process_log`;
CREATE TABLE IF NOT EXISTS `complaint_process_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `complaint_id` int unsigned NOT NULL COMMENT '關聯客訴主表',
  `stage` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '進程階段',
  `stage_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'main' COMMENT '關卡類型：main=標準主關卡/custom_main=自訂主關卡/cosign=加簽',
  `assigned_to` int unsigned DEFAULT NULL COMMENT '被指派人 user.id',
  `assigned_by` int unsigned DEFAULT NULL COMMENT '指派者 user.id',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '處理中/已完成/已駁回/逾期',
  `action` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '動作描述',
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '補充說明',
  `next_stage` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '下一階段',
  `next_assigned_to` int unsigned DEFAULT NULL COMMENT '下一階段指派對象 user.id',
  `assigned_at` datetime DEFAULT NULL COMMENT '指派時間',
  `completed_at` datetime DEFAULT NULL COMMENT '完成時間',
  `deadline_at` datetime DEFAULT NULL COMMENT '處理期限',
  `sort_order` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '流程排序序號（補零字串，如 01、02、02.01），直接 SQL ORDER BY 排序，NULL=舊資料',
  `parent_id` int unsigned DEFAULT NULL COMMENT '父關卡 process_log.id，NULL=主幹關卡',
  `created_by` int unsigned DEFAULT NULL COMMENT '建立者 user.id（系統自動=SYSTEM_USER_ID，流程調整新增=操作者，舊資料=NULL）',
  `deleted_at` datetime DEFAULT NULL COMMENT '軟刪時間（流程調整移除時記錄，自管軟刪）',
  `deleted_by` int unsigned DEFAULT NULL COMMENT '執行移除的操作者 user.id',
  `created_at` datetime NOT NULL COMMENT '建立時間',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT '最後異動時間',
  PRIMARY KEY (`id`),
  KEY `idx_process_log_complaint_id` (`complaint_id`),
  KEY `idx_process_log_assigned_to` (`assigned_to`),
  KEY `idx_process_log_status` (`status`),
  KEY `idx_process_log_complaint_stage` (`complaint_id`,`stage`),
  KEY `idx_process_log_complaint_sort` (`complaint_id`,`sort_order`),
  KEY `idx_process_log_stage_type` (`stage_type`),
  KEY `idx_process_log_deleted_at` (`deleted_at`),
  KEY `idx_process_log_status_stage_type` (`status`,`stage_type`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14947 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
