-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.ha_dialogue_training_item 結構
DROP TABLE IF EXISTS `ha_dialogue_training_item`;
CREATE TABLE IF NOT EXISTS `ha_dialogue_training_item` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '稽核類型: 電訪(Mr.K-Call)',
  `dialogue_training_client_role_id` int NOT NULL COMMENT '會議助理-對話訓練-客戶類型ID',
  `client_info` json NOT NULL COMMENT '客戶基本資訊',
  `ignore_tag` tinyint NOT NULL DEFAULT '1' COMMENT '是否忽略標註(忽略:1, 不忽略:0)',
  `language` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'zh-TW' COMMENT '語系: 台灣(zh-TW)',
  `file_path` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '圖機檔案位置',
  `user_id` int NOT NULL COMMENT '講解人ID',
  `audit_project_id` bigint NOT NULL COMMENT '稽核專案ID',
  `audit_project_version_id` bigint NOT NULL COMMENT '稽核專案版本ID',
  `tag_result` json DEFAULT NULL COMMENT '標籤結果',
  `transcription_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '轉錄服務ID',
  `transcription` longtext COLLATE utf8mb4_unicode_ci COMMENT '逐字稿內容',
  `speaker_labels` tinyint NOT NULL DEFAULT '0' COMMENT '多少位發言者(講解者+客戶)',
  `reply_info` json DEFAULT NULL COMMENT 'AI對話相關資訊',
  `audit_info` json DEFAULT NULL COMMENT 'AI稽核相關資訊',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '處理狀態',
  `explained_date` date DEFAULT (curdate()) COMMENT '講解日期',
  `duration` int NOT NULL COMMENT '時間長度(秒)',
  `deleted_by` int DEFAULT NULL COMMENT '刪除人ID',
  `performed_at` timestamp NULL DEFAULT NULL COMMENT '工作執行日期',
  `called_at` timestamp NULL DEFAULT NULL COMMENT '撥出時間',
  `extracted_at` timestamp NULL DEFAULT NULL COMMENT '轉檔時間',
  `transcribed_at` timestamp NULL DEFAULT NULL COMMENT '轉錄時間',
  `taged_at` timestamp NULL DEFAULT NULL COMMENT '標籤時間',
  `audited_at` timestamp NULL DEFAULT NULL COMMENT '稽核時間',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立時間',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '刪除時間',
  PRIMARY KEY (`id`),
  KEY `ha_dialogue_training_item_type_index` (`type`),
  KEY `role_index` (`dialogue_training_client_role_id`),
  KEY `ha_dialogue_training_item_user_id_index` (`user_id`),
  KEY `project_index` (`audit_project_id`),
  KEY `version_index` (`audit_project_version_id`),
  KEY `ha_dialogue_training_item_status_index` (`status`),
  KEY `ha_dialogue_training_item_explained_date_index` (`explained_date`),
  KEY `ha_dialogue_training_item_deleted_by_index` (`deleted_by`),
  KEY `created_updated_index` (`created_at`,`updated_at`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='會議助理-對話訓練-稽核紀錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
