-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  程序 als.GetAuditSum 結構
DROP PROCEDURE IF EXISTS `GetAuditSum`;
DELIMITER //
CREATE PROCEDURE `GetAuditSum`(
	IN `startDate` DATE,
	IN `endDate` DATE
)
    COMMENT '取得AI稽核相關數量：每天稽核數量、AI判斷有誤數量、逐字稿有誤數量'
BEGIN
	SELECT
        DATE(ai.created_at) AS `CreateDate`,
        COUNT(ai.id) AS `稽核數量`,
        SUM(CASE
        	   WHEN ar.id IS NOT NULL THEN 1
            WHEN JSON_CONTAINS(af.audit_feedback_type_ids, '1') THEN 1
            ELSE 0
        END) AS `AI判斷有誤數量`,
        SUM(CASE
            WHEN JSON_CONTAINS(af.audit_feedback_type_ids, '3') THEN 1
            ELSE 0
        END) AS `逐字稿有誤數量`
    FROM audit_item AS ai
    LEFT JOIN audit_feedback AS af ON af.audit_item_id = ai.id
    LEFT JOIN audit_review AS ar ON ar.audit_item_id = ai.id
    WHERE
        ai.deleted_at IS NULL AND
        DATE(ai.created_at) BETWEEN startDate AND endDate
    GROUP BY `CreateDate`
    ORDER BY `CreateDate` ASC;
END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
