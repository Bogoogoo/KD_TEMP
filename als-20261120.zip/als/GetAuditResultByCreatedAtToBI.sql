-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  程序 als.GetAuditResultByCreatedAtToBI 結構
DROP PROCEDURE IF EXISTS `GetAuditResultByCreatedAtToBI`;
DELIMITER //
CREATE PROCEDURE `GetAuditResultByCreatedAtToBI`(
	IN `p_search_start_time` TIMESTAMP,
	IN `p_search_end_time` TIMESTAMP
)
    COMMENT '提供給數中用於BI抓取AI質檢結果'
BEGIN
    SELECT
        ai.`id`,
        ai.`type`,
        ai.`task_id`,
        ai.`task_number`,
        ai.`file_path`,
        ai.`genesys_record_id`,
        ai.`audit_project_id`,
        ai.`audit_project_version_id`,
        ai.`transcription_id`,
        ai.`status`,
        ai.`explained_date`,
        ai.`duration`,
        ai.`transcribed_at`,
        ai.`audited_at`,
        ai.`created_at`,
        ai.`updated_at`,
        jt1.group_name,
        jt1.item_name,
        jt1.type AS `type1`,
        jt1.result,
        jt1.confidence,
        jt1.quote,
        jt1.analysis,
        jt1.location
    FROM
        audit_result AS ar -- 將 audit_result 表格別名為 ar
    LEFT JOIN
        audit_item AS ai ON ar.audit_item_id = ai.id -- LEFT JOIN audit_item 表格，並別名為 ai
    LEFT JOIN -- 將此 JOIN 改為 LEFT JOIN 以確保即使 JSON_TABLE 無法解析也能返回主表的行
        JSON_TABLE(
            -- 使用 CASE WHEN 判斷 audit_result.audit_result 是否為有效 JSON
            CASE
                WHEN JSON_VALID(ar.audit_result) = 1 THEN ar.audit_result -- 如果是有效 JSON，則使用原始 JSON
                ELSE '{"scoring_groups": []}' -- 如果不是有效 JSON，則提供一個空的 JSON 結構，避免 JSON_TABLE 報錯
            END,
            '$.scoring_groups[*]' COLUMNS(
                scoring_groups_index FOR ORDINALITY, -- scoring_groups 的索引，從 1 開始
                group_name VARCHAR(255) PATH '$.group_name', -- 提取 group_name
                NESTED PATH '$.evaluation_items[*]' COLUMNS(
                    evaluation_items_index FOR ORDINALITY, -- evaluation_items 的索引，從 1 開始
                    type VARCHAR(50) PATH '$.type', -- 提取 type
                    result VARCHAR(50) PATH '$.result', -- 提取 result
                    item_name VARCHAR(255) PATH '$.item_name', -- 提取 item_name
                    confidence VARCHAR(50) PATH '$.confidence', -- 提取 confidence
                    NESTED PATH '$.evidences[*]' COLUMNS(
                        quote TEXT PATH '$.quote', -- 提取 quote
                        analysis TEXT PATH '$.analysis', -- 提取 analysis
                        location VARCHAR(255) PATH '$.location' -- 提取 location
                    )
                )
            )
        ) AS jt1 ON 1=1 -- 當 JSON_TABLE 作為 LEFT JOIN 的一部分時，通常使用 ON 1=1
    WHERE
    	  ai.status IN (100, 86, 21, 22, 84, 86) AND 
        ai.created_at BETWEEN p_search_start_time AND p_search_end_time -- 根據傳入的參數篩選 created_at 區間
    ORDER BY
        ai.created_at DESC; -- 根據 created_at 降序排列，您可以根據需要調整排序方式
END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
