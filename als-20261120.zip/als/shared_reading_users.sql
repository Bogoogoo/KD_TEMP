-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 移除臨時表格，並建立最終檢視結構
DROP TABLE IF EXISTS `shared_reading_users`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `shared_reading_users` AS select `user`.`id` AS `id`,`user`.`name` AS `name`,`user`.`employee_id` AS `employee_id`,if((`permission_management_trainee`.`ch_name` is not null),`permission_management_trainee`.`ch_name`,`permission_title`.`ch_name`) AS `title`,`permission_department`.`ch_name` AS `department`,`permission_office`.`hrs_code` AS `hrs_code`,`user`.`permission_setting_id` AS `permission_setting_id`,`permission_setting`.`area_id` AS `area_id`,`permission_setting`.`department_id` AS `department_id`,`user`.`permission_office_id` AS `permission_office_id`,`permission_setting`.`title_id` AS `title_id`,`user`.`permission_management_trainee_id` AS `permission_management_trainee_id` from ((((((`user` left join `permission_setting` on((`permission_setting`.`id` = `user`.`permission_setting_id`))) left join `permission_area` on((`permission_area`.`id` = `permission_setting`.`area_id`))) left join `permission_department` on((`permission_department`.`id` = `permission_setting`.`department_id`))) left join `permission_title` on((`permission_title`.`id` = `permission_setting`.`title_id`))) left join `permission_office` on((`permission_office`.`id` = `user`.`permission_office_id`))) left join `permission_management_trainee` on(((`permission_management_trainee`.`id` = `user`.`permission_management_trainee_id`) and (`permission_management_trainee`.`is_show` = 1)))) where (json_contains(`permission_setting`.`category_id_data`,'6') and json_overlaps(json_extract(`permission_setting`.`item_id_data`,'$[*].item_id'),'[31,32,43]') and (not((`user`.`name` like '%共用%'))) and (not((`user`.`name` like '%測試%'))) and (not((`user`.`name` like '%業務%'))) and (not((`user`.`name` like '%業管%'))) and (`user`.`status` = 2) and (`user`.`id` not in (1,665,3328,893,4587,4642,675,254,4689,1081,4622,4746,3720,3568,5005,4516,4819,3161,5155,690,1675,2905,4738,5229,704,4498,4577,5295,5317)) and ((`permission_office`.`hrs_code` in ('SCS001','SCS003')) or ((`permission_office`.`hrs_code` = 'SCS002') and (`permission_title`.`id` <> 14)))) order by `permission_office`.`hrs_code`,`permission_title`.`id`,`user`.`id`
;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
