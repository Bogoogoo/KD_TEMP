-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.uniforms_recall 結構
DROP TABLE IF EXISTS `uniforms_recall`;
CREATE TABLE IF NOT EXISTS `uniforms_recall` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `catelog_id` int NOT NULL COMMENT '目錄ID',
  `amount` int NOT NULL COMMENT '數量',
  `small_id` int NOT NULL COMMENT '調回單位',
  `main_small_id` int NOT NULL COMMENT '主要倉庫',
  `applicant` int NOT NULL COMMENT '申請人',
  `behavior_status` tinyint(1) DEFAULT '8' COMMENT '行為狀態(8,9,10)',
  `confirm_user` int DEFAULT '0' COMMENT '確認人員',
  `confirm_date` datetime DEFAULT NULL COMMENT '確認時間',
  `cancel_user` int DEFAULT '0' COMMENT '取消人',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否顯示',
  `created_at` datetime NOT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`),
  KEY `catelog_id` (`catelog_id`),
  KEY `applicant` (`applicant`),
  KEY `warehouse_id` (`small_id`) USING BTREE,
  CONSTRAINT `FK_uniforms_recall_uniforms_catelog` FOREIGN KEY (`catelog_id`) REFERENCES `uniforms_catelog` (`id`),
  CONSTRAINT `FK_uniforms_recall_uniforms_warehouse` FOREIGN KEY (`small_id`) REFERENCES `uniforms_warehouse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='制服 - 調回記錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
