-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.daily_report_for_sales 結構
DROP TABLE IF EXISTS `daily_report_for_sales`;
CREATE TABLE IF NOT EXISTS `daily_report_for_sales` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `user_id` int NOT NULL COMMENT '使用者ID',
  `report_date` date NOT NULL COMMENT '建檔日期',
  `report_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '業務日報(CRM日報)' COMMENT '業務日報類型：業務日報(CRM日報)、開發業務日報(CRM日報)、业务日报(CRM日报)、电访员和产顾日报(CRM日报)、招商日报(CRM日报)、每日报表(业管)、每日报表、展示館參訪日報(CRM日報)',
  `is_show` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`),
  KEY `u_index` (`user_id`),
  KEY `uris` (`user_id`,`report_date`,`is_show`)
) ENGINE=InnoDB AUTO_INCREMENT=53068 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作日報管理-每日報表(業務)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
