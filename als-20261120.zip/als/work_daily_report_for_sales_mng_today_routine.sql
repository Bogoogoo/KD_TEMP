-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.work_daily_report_for_sales_mng_today_routine 結構
DROP TABLE IF EXISTS `work_daily_report_for_sales_mng_today_routine`;
CREATE TABLE IF NOT EXISTS `work_daily_report_for_sales_mng_today_routine` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `user_id` int NOT NULL COMMENT '使用者流水號',
  `organization_a_id` tinyint NOT NULL COMMENT '使用單位',
  `organization_b_id` tinyint NOT NULL COMMENT '使用單位b',
  `today_routine_item` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '今日例行工作事項項目',
  `today_routine_hr` decimal(10,1) NOT NULL COMMENT '今日例行工作事項時數',
  `today_routine_percent` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '今日例行工作事項完成度',
  `sales_mng_category_id` smallint NOT NULL COMMENT '今日例行工作事項的事項類別',
  `today_routine_memo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '今日例行工作事項備註',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否顯示',
  `created_at` datetime NOT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `today_routine_item_id` (`sales_mng_category_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作回報管理 - 業管每日工作回報(今日例行工作事項)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
