-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.permission_category 結構
DROP TABLE IF EXISTS `permission_category`;
CREATE TABLE IF NOT EXISTS `permission_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ch_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `sort` tinyint NOT NULL,
  `is_show` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 正在傾印表格  als.permission_category 的資料：~11 rows (近似值)
DELETE FROM `permission_category`;
INSERT INTO `permission_category` (`id`, `ch_name`, `language_id`, `sort`, `is_show`, `created_at`, `updated_at`) VALUES
	(1, '系統管理', 11, 1, 1, '2020-03-27 15:39:08', '2023-04-25 03:28:56'),
	(2, '系統信箱', 12, 99, 1, '2020-03-27 15:39:08', '2023-04-25 03:28:50'),
	(3, '總務管理', 319, 4, 1, '2020-09-15 11:48:38', '2025-08-25 06:14:05'),
	(4, '制服管理', 359, 0, 0, '2020-11-06 09:19:44', '2024-03-11 02:24:27'),
	(5, '生產管理', 360, 5, 1, '2020-11-06 09:21:14', '2023-02-01 02:25:58'),
	(6, '工作日報管理', 565, 2, 1, '2022-01-12 10:39:13', '2023-02-01 02:25:09'),
	(7, '客戶/銷售相關明細', 584, 6, 1, '2022-01-24 10:23:07', '2023-02-01 02:25:59'),
	(8, '訂單中介管理', 897, 8, 0, '2024-11-06 16:17:23', '2025-06-20 06:20:07'),
	(9, 'AI質檢', 905, 9, 1, '2025-02-19 10:32:51', '2025-10-07 12:24:45'),
	(10, 'AI會議助理', 914, 8, 1, '2025-08-20 08:32:36', '2025-10-08 01:05:29'),
	(11, '客訴管理', 928, 10, 1, '2026-06-08 10:25:58', '2026-07-17 05:03:09');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
