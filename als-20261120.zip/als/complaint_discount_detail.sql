-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_discount_detail 結構
DROP TABLE IF EXISTS `complaint_discount_detail`;
CREATE TABLE IF NOT EXISTS `complaint_discount_detail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '明細ID',
  `complaint_id` int unsigned NOT NULL COMMENT '關聯 complaint.id',
  `item_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '折讓品號（自由輸入，不驗證存在）',
  `quantity` decimal(10,2) DEFAULT NULL COMMENT '折讓數量',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否為生效明細：1=生效/0=停用',
  `created_by` int NOT NULL COMMENT '建立者 user.id',
  `updated_by` int DEFAULT NULL COMMENT '更新者 user.id',
  `created_at` datetime DEFAULT NULL COMMENT '建立時間（建立時由後端帶入 Carbon::now）',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間（DB 維護 CURRENT_TIMESTAMP）',
  PRIMARY KEY (`id`),
  KEY `idx_discount_detail_complaint_active` (`complaint_id`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=280 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴折讓品號明細';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
