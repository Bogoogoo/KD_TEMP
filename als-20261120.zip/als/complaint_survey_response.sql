-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_survey_response 結構
DROP TABLE IF EXISTS `complaint_survey_response`;
CREATE TABLE IF NOT EXISTS `complaint_survey_response` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '回饋ID',
  `complaint_id` int unsigned NOT NULL COMMENT '關聯 complaint.id',
  `complaint_survey_question_id` int unsigned NOT NULL COMMENT '關聯 complaint_survey_question.id',
  `answer` json NOT NULL COMMENT '回答內容 JSON array；未填寫使用 []，單選 [1]，多選 [1,2,3]，文字題 ["文字"]',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否目前有效：1=有效/0=歷史或停用',
  `created_by` int DEFAULT NULL COMMENT '建立者 user.id',
  `updated_by` int DEFAULT NULL COMMENT '更新者 user.id',
  `created_at` datetime DEFAULT NULL COMMENT '建立時間（建立時由後端帶入）',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間（DB 維護 CURRENT_TIMESTAMP）',
  PRIMARY KEY (`id`),
  KEY `idx_survey_response_complaint` (`complaint_id`),
  KEY `idx_survey_response_question` (`complaint_survey_question_id`),
  KEY `idx_survey_response_active` (`complaint_id`,`complaint_survey_question_id`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=582 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴滿意度問卷回答';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
