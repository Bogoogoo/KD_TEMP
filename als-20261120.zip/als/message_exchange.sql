-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.message_exchange 結構
DROP TABLE IF EXISTS `message_exchange`;
CREATE TABLE IF NOT EXISTS `message_exchange` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `sender_id` int NOT NULL COMMENT '寄件人',
  `receiver_id` int NOT NULL COMMENT '收件人',
  `reply_id` int NOT NULL DEFAULT '0' COMMENT '回覆的寄件ID',
  `is_read` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否讀取',
  `message_id` int NOT NULL DEFAULT '0' COMMENT '寄件ID',
  `come_from` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '訊息來源：main(每日報表)、sales(每日報表(業管))、month(每月月報)、forSales(業務日報)',
  `report_owner_id` int DEFAULT NULL COMMENT '報表擁有者ID',
  `report_id` int DEFAULT NULL COMMENT '報表ID',
  `sender_is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '寄件者顯示',
  `receiver_is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '收件者顯示',
  `created_at` datetime NOT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_message_exchange_message` (`message_id`) USING BTREE,
  KEY `receiver_id` (`receiver_id`) USING BTREE,
  KEY `sender_id` (`sender_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=65391 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='寄件、回覆記錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
