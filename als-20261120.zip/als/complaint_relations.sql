-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_relations 結構
DROP TABLE IF EXISTS `complaint_relations`;
CREATE TABLE IF NOT EXISTS `complaint_relations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `complaint_id` int unsigned NOT NULL COMMENT '主客訴 ID',
  `related_complaint_id` int unsigned NOT NULL COMMENT '關聯客訴 ID',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否有效：1=生效/0=停用',
  `created_by` int unsigned DEFAULT NULL COMMENT '建立者 user.id',
  `created_at` datetime DEFAULT NULL COMMENT '建立時間（建立時由後端帶入 Carbon::now）',
  `updated_by` int unsigned DEFAULT NULL COMMENT '更新者 user.id',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間（DB 維護 CURRENT_TIMESTAMP ON UPDATE）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_relation` (`complaint_id`,`related_complaint_id`),
  KEY `idx_complaint_id` (`complaint_id`),
  KEY `idx_related_complaint_id` (`related_complaint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴關聯表';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
