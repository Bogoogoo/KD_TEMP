-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 移除臨時表格，並建立最終檢視結構
DROP TABLE IF EXISTS `shared_reading_reports`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `shared_reading_reports` AS select `daily_reports`.`id` AS `id`,`daily_reports`.`user_id` AS `user_id`,`daily_reports`.`report_date` AS `report_date`,'一般日報' AS `report_type`,`daily_reports`.`suggest` AS `reading_plan`,`daily_reports`.`created_at` AS `created_at` from `daily_reports` where ((`daily_reports`.`report_date` between '2026-04-09' and '2026-05-08') and (`daily_reports`.`is_show` = 1) and ((`daily_reports`.`suggest` like '%共讀心得%') or (`daily_reports`.`suggest` like '%共读心得%') or (`daily_reports`.`suggest` like '%Reading Reflection%')) and `daily_reports`.`user_id` in (select `shared_reading_users`.`id` from `shared_reading_users`)) union select `daily_report_sales`.`id` AS `id`,`daily_report_sales`.`user_id` AS `user_id`,`daily_report_sales`.`report_date` AS `report_date`,'專案日報' AS `report_type`,`daily_report_sales`.`suggest` AS `reading_plan`,`daily_report_sales`.`created_at` AS `created_at` from `daily_report_sales` where ((`daily_report_sales`.`report_date` between '2026-04-09' and '2026-05-08') and (`daily_report_sales`.`is_show` = 1) and ((`daily_report_sales`.`suggest` like '%共讀心得%') or (`daily_report_sales`.`suggest` like '%共读心得%') or (`daily_report_sales`.`suggest` like '%Reading Reflection%')) and `daily_report_sales`.`user_id` in (select `shared_reading_users`.`id` from `shared_reading_users`)) union select `daily_report_for_sales_detail`.`daily_report_for_sales_id` AS `id`,`daily_report_for_sales`.`user_id` AS `user_id`,`daily_report_for_sales`.`report_date` AS `report_date`,'業務日報' AS `report_type`,`daily_report_for_sales_detail`.`feedback` AS `reading_plan`,`daily_report_for_sales`.`created_at` AS `created_at` from (`daily_report_for_sales_detail` left join `daily_report_for_sales` on((`daily_report_for_sales`.`id` = `daily_report_for_sales_detail`.`daily_report_for_sales_id`))) where ((`daily_report_for_sales_detail`.`report_date` between '2026-04-09' and '2026-05-08') and (`daily_report_for_sales_detail`.`is_show` = 1) and (`daily_report_for_sales`.`is_show` = 1) and ((`daily_report_for_sales_detail`.`content1` like '%共讀心得%') or (`daily_report_for_sales_detail`.`content1` like '%共读心得%') or (`daily_report_for_sales_detail`.`content1` like '%Reading Reflection%')) and (`daily_report_for_sales_detail`.`feedback` is not null) and (`daily_report_for_sales_detail`.`feedback` <> '') and `daily_report_for_sales`.`user_id` in (select `shared_reading_users`.`id` from `shared_reading_users`))
;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
