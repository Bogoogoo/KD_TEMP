-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  程序 als.CleanDuplicateReportAssigns 結構
DROP PROCEDURE IF EXISTS `CleanDuplicateReportAssigns`;
DELIMITER //
CREATE PROCEDURE `CleanDuplicateReportAssigns`()
BEGIN
    -- 1. DECLARE 必須放在最前面
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        -- 確保出錯時也會清理臨時表
        DROP TEMPORARY TABLE IF EXISTS tmp_to_remove;
    END;

    -- 2. 接下來才是執行 SET 或其他邏輯
    SET SESSION sort_buffer_size = 1024 * 1024 * 16;

    START TRANSACTION;

    -- 3. 建立臨時表
    CREATE TEMPORARY TABLE IF NOT EXISTS tmp_to_remove (
        id INT PRIMARY KEY
    ) ENGINE=InnoDB;

    -- 4. 找出重複資料 (核心邏輯不變)
    INSERT INTO tmp_to_remove (id)
    SELECT id
    FROM (
        SELECT id,
               ROW_NUMBER() OVER (
                   PARTITION BY parent_id, parent_type, user_id 
                   ORDER BY 
                       (is_assigns = 1 
                        AND content IS NOT NULL 
                        AND TRIM(content) != '' 
                        AND content != '閱') DESC,
                       (is_assigns = 1) DESC,
                       created_at ASC,
                       id ASC
               ) as rn
        FROM daily_report_assigns
    ) t
    WHERE t.rn > 1;

    -- 5. 執行搬移與刪除
    IF (SELECT EXISTS (SELECT 1 FROM tmp_to_remove)) THEN
        
        INSERT INTO daily_report_assigns_delete (
            id, parent_id, parent_type, user_id, content, is_assigns, created_at, updated_at
        )
        SELECT id, parent_id, parent_type, user_id, content, is_assigns, created_at, updated_at
        FROM daily_report_assigns
        WHERE id IN (SELECT id FROM tmp_to_remove);

        DELETE FROM daily_report_assigns
        WHERE id IN (SELECT id FROM tmp_to_remove);
        
    END IF;

    -- 6. 清理並提交
    DROP TEMPORARY TABLE IF EXISTS tmp_to_remove;
    
    COMMIT;
END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
