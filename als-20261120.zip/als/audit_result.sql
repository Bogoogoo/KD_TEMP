-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.audit_result 結構
DROP TABLE IF EXISTS `audit_result`;
CREATE TABLE IF NOT EXISTS `audit_result` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `audit_item_id` bigint NOT NULL COMMENT '稽核id',
  `audit_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '稽核結果',
  `is_invite_success` tinyint DEFAULT NULL COMMENT 'Mr.K-Call 邀約成果(來自AI)',
  `total_violations` tinyint DEFAULT NULL COMMENT 'Mr.K-Call 違規次數(來自AI)',
  `total_score` tinyint DEFAULT NULL COMMENT 'Mr.K-Meeting 評分總分(來自AI)',
  `pass_score` tinyint DEFAULT NULL COMMENT 'Mr.K-Meeting 合格分數(來自AI)',
  `is_pass` tinyint DEFAULT NULL COMMENT 'Mr.K-Meeting 評分是否通過(來自AI)',
  `deleted_by` int DEFAULT NULL COMMENT '刪除者ID',
  `created_at` timestamp NOT NULL DEFAULT (now()) COMMENT '建立日期',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '刪除時間',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14292 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='稽核結果(AI判斷)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
