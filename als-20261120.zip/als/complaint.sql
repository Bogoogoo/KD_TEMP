-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint 結構
DROP TABLE IF EXISTS `complaint`;
CREATE TABLE IF NOT EXISTS `complaint` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主鍵',
  `complaint_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客訴編號（YYYYMM-NNNNN）',
  `created_at` datetime NOT NULL COMMENT '建立時間',
  `created_date_short` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '建立日期簡寫（MM/DD）',
  `reporter` int unsigned DEFAULT NULL COMMENT '填單人 user.id',
  `report_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '回報類型',
  `issue_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '問題類型：產品類型/服務類型',
  `complaint_source` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客訴來源',
  `company_code` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公司代號',
  `sap_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SAP 客戶代號（NULL=未帶入）',
  `company_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公司名稱',
  `contact_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '聯絡人',
  `contact_gender` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '性別',
  `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '聯絡電話',
  `region` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '區域',
  `tag` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '貼標（需貼標／待刪除標籤／已貼標／移除標籤，NULL=未貼標）',
  `order_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '訂單編號',
  `ship_date` date DEFAULT NULL COMMENT '出貨日期',
  `item_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品號',
  `batch_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '批次',
  `product_qc_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '產品QC碼',
  `quantity` decimal(10,2) DEFAULT NULL COMMENT '數量',
  `product_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '產品類型',
  `defect_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '瑕疵類型',
  `defect_type_new` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新增瑕疵類型',
  `service_category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服務需求分類',
  `service_category_new` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新增服務需求分類',
  `complaint_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客訴類型',
  `complaint_type_new` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '新增客訴類型',
  `do_not_disturb` tinyint NOT NULL DEFAULT '0' COMMENT '勿擾申請：0=否 1=是',
  `dnd_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '勿擾申請原因（NULL=未填）',
  `dnd_person` int DEFAULT NULL COMMENT '勿擾申請執行人 user.id',
  `dnd_date` date DEFAULT NULL COMMENT '勿擾日期',
  `has_photo` tinyint NOT NULL DEFAULT '0' COMMENT '有照片：0=否 1=是',
  `has_video` tinyint NOT NULL DEFAULT '0' COMMENT '有影片：0=否 1=是',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '狀況說明',
  `has_discount` tinyint NOT NULL DEFAULT '0' COMMENT '折讓：0=否 1=是',
  `discount_amount` decimal(10,2) DEFAULT NULL COMMENT '折讓金額',
  `discount_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '折讓原因',
  `discount_date` date DEFAULT NULL COMMENT '折讓日期',
  `discount_person` int DEFAULT NULL COMMENT '折讓處理人 user.id',
  `handler_level1` int unsigned DEFAULT NULL COMMENT '業一/業二處理人 user.id',
  `handler_level1_hint` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '業一/業二處理人員提示',
  `handler_level3` int unsigned DEFAULT NULL COMMENT '業三/主管處理人 user.id',
  `handler_level3_hint` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '業三/主管處理人員提示',
  `is_duplicate` tinyint NOT NULL DEFAULT '0' COMMENT '是否重複：0=否 1=是',
  `duplicate_ref` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '重複參照客訴編號',
  `complaint_grade` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客訴分級：A/B/C/D/X',
  `grade_date` date DEFAULT NULL COMMENT '分級日期',
  `responsible_unit` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '權責單位',
  `responsible_unit_handler` int unsigned DEFAULT NULL COMMENT '權責單位處理人 user.id',
  `co_responsible_handler` int unsigned DEFAULT NULL COMMENT '權責單位協同處理人 user_id（生產單位自動帶潘李賓 686；NULL=非生產單位或未判定）',
  `responsible_judge_time` datetime DEFAULT NULL COMMENT '判斷權責處理時間',
  `type_analysis` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '類型分析',
  `type_analysis2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '類型分析2',
  `defect_judgment` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '判斷瑕疵狀況',
  `confidence` json DEFAULT NULL COMMENT 'AI信心度JSON',
  `handler_l1_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '業一/業二處理備註',
  `handler_l1_progress` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '業一/業二處理進度',
  `handler_l1_completed_at` datetime DEFAULT NULL COMMENT '業一/業二完成時間',
  `handler_l3_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '業三/主管處理備註',
  `handler_l3_progress` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '業三/主管處理進度',
  `handler_l3_completed_at` datetime DEFAULT NULL COMMENT '業三/主管完成時間',
  `responsible_unit_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '權責單位備註',
  `responsible_unit_reply` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '權責單位回覆',
  `responsible_unit_progress` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '權責單位處理進度',
  `responsible_unit_completed_at` datetime DEFAULT NULL COMMENT '權責單位完成時間',
  `admin_handler` int unsigned DEFAULT NULL COMMENT '業管處理人 user.id',
  `admin_progress` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '業管處理進度',
  `admin_completed_at` datetime DEFAULT NULL COMMENT '業管完成時間',
  `admin_note` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '業管備註',
  `bpm_number` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'BPM簽呈編號',
  `need_notify_customer` tinyint NOT NULL DEFAULT '0' COMMENT '需通知客戶：0=否 1=是',
  `notify_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '通知內容',
  `notify_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '通知狀態',
  `sms_receive_date` date DEFAULT NULL COMMENT '簡訊收件日期',
  `sms_receive_progress` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '簡訊收件進度',
  `sms_thanks_date` date DEFAULT NULL COMMENT '簡訊致謝日期',
  `sms_thanks_progress` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '簡訊致謝進度',
  `gift_date` date DEFAULT NULL COMMENT '送禮日期',
  `gift_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '禮品內容',
  `followup_progress` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '電訪關心進度',
  `followup_completed_at` datetime DEFAULT NULL COMMENT '電訪關心完成時間',
  `followup_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '電訪關心備註',
  `process_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '處理時間紀錄',
  `survey_data` json DEFAULT NULL COMMENT '滿意度調查資料',
  `line_tag` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'LINE貼標',
  `created_by` int unsigned DEFAULT NULL COMMENT '建立者 user.id',
  `updated_at` datetime DEFAULT NULL COMMENT '更新時間',
  `updated_by` int unsigned DEFAULT NULL COMMENT '更新者 user.id',
  `deleted_by` int DEFAULT NULL COMMENT '刪除者 user.id；未刪除為 NULL',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '刪除時間；未刪除為 NULL，NOT NULL 即已軟刪除',
  PRIMARY KEY (`id`),
  KEY `idx_complaint_code` (`complaint_code`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_company_code` (`company_code`),
  KEY `idx_contact_phone` (`contact_phone`),
  KEY `idx_contact_name` (`contact_name`),
  KEY `idx_order_number` (`order_number`),
  KEY `idx_complaint_grade` (`complaint_grade`),
  KEY `idx_responsible_unit` (`responsible_unit`),
  KEY `idx_region` (`region`),
  KEY `idx_complaint_deleted_at` (`deleted_at`),
  KEY `idx_complaint_reporter` (`reporter`),
  KEY `idx_complaint_handler_level1` (`handler_level1`),
  KEY `idx_complaint_issue_type` (`issue_type`),
  KEY `idx_complaint_has_discount` (`has_discount`)
) ENGINE=InnoDB AUTO_INCREMENT=1192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴主表';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
