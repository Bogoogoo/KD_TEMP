-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.daily_report_boss 結構
DROP TABLE IF EXISTS `daily_report_boss`;
CREATE TABLE IF NOT EXISTS `daily_report_boss` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `department_id` int NOT NULL COMMENT '部門ID',
  `organization_a_id` int DEFAULT NULL COMMENT '組織A區ID',
  `organization_b_id` int DEFAULT NULL COMMENT '組織B區ID',
  `organization_c_id` int DEFAULT NULL COMMENT '組織C區ID',
  `permission_office_id` int DEFAULT NULL COMMENT '辦公位置ID',
  `user_ids` json NOT NULL COMMENT '使用者IDs',
  `level` tinyint(1) NOT NULL DEFAULT '1' COMMENT '層級：全部(1), 下屬(2), 同階(3), 同階+下屬幹部(4)',
  `report_date` date DEFAULT NULL COMMENT '開始查閱工作日報日期',
  `is_mark` tinyint NOT NULL COMMENT '是否批示(否(0), 是(1))',
  `is_love` tinyint NOT NULL COMMENT '是否最愛(否(0), 是(1))',
  `is_notic` tinyint NOT NULL COMMENT '是否通知(否(0), 是(1))',
  `is_show` tinyint NOT NULL COMMENT '是否顯示(否(0), 是(1))',
  `creator_id` int NOT NULL COMMENT '建立者ID',
  `updator_id` int DEFAULT NULL COMMENT '更新者ID',
  `created_at` timestamp NOT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=621 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='日報權限管理-預設boss';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
