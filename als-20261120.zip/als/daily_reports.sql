-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.daily_reports 結構
DROP TABLE IF EXISTS `daily_reports`;
CREATE TABLE IF NOT EXISTS `daily_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `instruct_status` tinyint NOT NULL COMMENT '批示狀態(0未批 1已批)',
  `report_word_num` int NOT NULL COMMENT '日報字數',
  `report_date` date NOT NULL COMMENT '日報日期',
  `today_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '今日成果',
  `business_trip` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '公出時間',
  `suggest` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '反映建議',
  `reading_plan` text COLLATE utf8mb4_unicode_ci COMMENT '共讀計畫',
  `renovation_warrior` text COLLATE utf8mb4_unicode_ci COMMENT '主管裝修共讀',
  `education_training` text COLLATE utf8mb4_unicode_ci COMMENT '教育訓練心得 JSON {"courseTitle":"...","courseReflection":"..."}',
  `quarterly_meeting_reflection` text COLLATE utf8mb4_unicode_ci COMMENT '季會心得內容（HTML，全體填寫）；NULL 或空字串代表未填寫',
  `assign` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '交辦復誦',
  `tomorrow_plan` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '明日計畫',
  `status` tinyint NOT NULL COMMENT '草稿(0), 繳交(1)',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_show` tinyint DEFAULT '1' COMMENT '是否顯示',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_user_show_date` (`user_id`,`is_show`,`report_date`)
) ENGINE=InnoDB AUTO_INCREMENT=222445 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
