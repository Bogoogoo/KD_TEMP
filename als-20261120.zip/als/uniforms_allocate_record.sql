-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.uniforms_allocate_record 結構
DROP TABLE IF EXISTS `uniforms_allocate_record`;
CREATE TABLE IF NOT EXISTS `uniforms_allocate_record` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `allocate_apply_id` int NOT NULL DEFAULT '0' COMMENT '調撥申請ID',
  `small_id` int NOT NULL COMMENT '調撥倉庫ID',
  `amount` int NOT NULL COMMENT '調撥數量',
  `lack_amount` int NOT NULL DEFAULT '0' COMMENT '待撥補數量',
  `type` enum('allocate','confirm') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作型態。allocate:調撥出庫/confirm:確認接收',
  `operator` int NOT NULL DEFAULT '0' COMMENT '操作人員',
  `is_cancel` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否刪除',
  `is_finished` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否完成',
  `created_at` datetime NOT NULL COMMENT '建立日期',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `allocate_apply_id` (`allocate_apply_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='制服 - 調撥(入庫)記錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
