-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.assets_sync_sap_template 結構
DROP TABLE IF EXISTS `assets_sync_sap_template`;
CREATE TABLE IF NOT EXISTS `assets_sync_sap_template` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `transaction_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作批次代號(代表同一批的操作，格式為：YmdHis-user_id)',
  `start_date` date NOT NULL COMMENT '查詢開始日期',
  `end_date` date NOT NULL COMMENT '查詢結束日期',
  `sap_data` json NOT NULL COMMENT 'SAP回傳的RawData',
  `process_data` json NOT NULL COMMENT '轉換成新後勤要執行的Data',
  `action` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作動作(新增(create), 修改(update), 刪除(delete), 不須操作(null))',
  `exception_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '異常錯誤訊息',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '執行結果(成功(1), 失敗(0))',
  `creator_id` int NOT NULL COMMENT '建立者',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建立日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9630 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='資產管理-sync SAP暫存表';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
