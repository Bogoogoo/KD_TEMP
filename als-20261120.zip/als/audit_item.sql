-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.audit_item 結構
DROP TABLE IF EXISTS `audit_item`;
CREATE TABLE IF NOT EXISTS `audit_item` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '類型',
  `crm_info` json DEFAULT NULL COMMENT 'CRM資訊',
  `ignore_tag` tinyint NOT NULL DEFAULT '1' COMMENT '是否忽略貼標稽核',
  `region` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '區域',
  `genesys_conversation_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'GenesysConversationID',
  `genesys_record_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Genesys轉出音檔ID',
  `task_id` bigint DEFAULT NULL COMMENT '交辦ID',
  `task_number` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '交辦編號',
  `phone_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '外撥電話',
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主要語言',
  `metadata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '擴展的JSON資料',
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '圖機檔案位置',
  `src_file_path` text COLLATE utf8mb4_unicode_ci COMMENT '原始檔案位置',
  `user_id` int DEFAULT NULL COMMENT '講解人id',
  `audit_project_id` bigint DEFAULT NULL COMMENT '稽核專案編號',
  `audit_project_version_id` bigint DEFAULT NULL COMMENT '稽核專案版本編號',
  `model_usage` json DEFAULT NULL COMMENT '模型使用紀錄',
  `tag_result` json DEFAULT NULL COMMENT '標籤結果',
  `transcription_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '轉錄服務ID',
  `transcription` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '逐字稿內容',
  `speaker_labels` tinyint NOT NULL DEFAULT '0' COMMENT '多少位發言者(講解者+客戶)',
  `invocation_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '執行稽核ID',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '處理狀態',
  `explained_date` date DEFAULT (curdate()) COMMENT '講解日期：預設為CRM-講解日期，若CRM-講解日期沒有值，會使用CRM-更新日期，若CRM-更新日期也沒有值，使用當下上傳日期',
  `duration` int NOT NULL COMMENT '時間長度(秒)',
  `created_by` int DEFAULT NULL,
  `deleted_by` int DEFAULT NULL COMMENT '刪除人ID',
  `performed_at` timestamp NOT NULL COMMENT '工作執行日期',
  `called_at` timestamp NULL DEFAULT NULL COMMENT '撥出時間',
  `extracted_at` timestamp NULL DEFAULT NULL COMMENT '轉檔日期',
  `transcribed_at` timestamp NULL DEFAULT NULL COMMENT '轉錄日期',
  `taged_at` timestamp NULL DEFAULT NULL COMMENT '標籤時間',
  `audited_at` timestamp NULL DEFAULT NULL COMMENT '稽核日期',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT (now()) COMMENT '更新日期',
  `canceled_at` timestamp NULL DEFAULT NULL COMMENT '取消日期',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '刪除日期',
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `task_number` (`task_number`),
  KEY `user_id` (`user_id`),
  KEY `audit_project_id` (`audit_project_id`),
  KEY `audit_project_version_id` (`audit_project_version_id`),
  KEY `explained_date` (`explained_date`)
) ENGINE=InnoDB AUTO_INCREMENT=20652 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
