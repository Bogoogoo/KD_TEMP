-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.uniforms_remand 結構
DROP TABLE IF EXISTS `uniforms_remand`;
CREATE TABLE IF NOT EXISTS `uniforms_remand` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `catelog_id` int NOT NULL COMMENT '目錄ID',
  `user_id` int NOT NULL DEFAULT '0' COMMENT '繳回人',
  `receive_id` int NOT NULL DEFAULT '0' COMMENT '領取ID',
  `amount` int NOT NULL COMMENT '數量',
  `applicant` int NOT NULL DEFAULT '0' COMMENT '填寫人',
  `remand_small_id` int NOT NULL DEFAULT '0' COMMENT '入庫倉庫',
  `cancel_user` int DEFAULT NULL COMMENT '取消人員',
  `is_show` tinyint(1) DEFAULT '1' COMMENT '是否顯示',
  `remand_date` datetime DEFAULT NULL COMMENT '繳回日期',
  `created_at` datetime NOT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`),
  KEY `uniforms_list_id` (`catelog_id`) USING BTREE,
  KEY `applicant` (`applicant`),
  KEY `remand_warehouse_id` (`remand_small_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='制服 - 繳回紀錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
