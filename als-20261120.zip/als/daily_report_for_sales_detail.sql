-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.daily_report_for_sales_detail 結構
DROP TABLE IF EXISTS `daily_report_for_sales_detail`;
CREATE TABLE IF NOT EXISTS `daily_report_for_sales_detail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `crm_id` bigint NOT NULL COMMENT 'CRM_ID',
  `daily_report_for_sales_id` int NOT NULL COMMENT '工作日報管理-每日報表(業務)ID',
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '業務類型',
  `work_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '工作類別',
  `touch_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '觸客類型',
  `company_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公司型態',
  `company_name1` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公司名稱',
  `company_name2` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '案例-公司名稱',
  `company_detail_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '公司詳細地址[簽呈：2412190026，大陸用]',
  `contact_user_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '聯絡人姓名',
  `contact_title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '聯絡人職稱',
  `case_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '案例名稱',
  `line` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '產品線代號',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '產品品號',
  `price` float DEFAULT NULL COMMENT '銷售預估金額',
  `quantity` int DEFAULT NULL COMMENT '數量',
  `content1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '最近工作內容(一)',
  `content2` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '最近工作內容(二)',
  `visit_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '拜訪地址[簽呈：2412190061，棄用]',
  `sign_in_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '拜訪記錄對象.簽到地址',
  `work_purpose` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '工作主旨(標籤)[簽呈：2411260160，台灣用]',
  `broad_based_outreach` int DEFAULT NULL COMMENT '廣度拜訪聯絡人[簽呈：2411260160，台灣用]',
  `daily_call_list_minutes` decimal(5,0) DEFAULT NULL COMMENT '[2023-12-28 棄用]Daily call list - Time(mins)',
  `daily_call_list_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'Daily call list& - Remark',
  `after_sending_call_list_minutes` decimal(5,0) DEFAULT NULL COMMENT '[2023-12-28 棄用]After Sending call list - Time(mins)',
  `after_sending_call_list_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '[2023-12-28 棄用]After Sending call list& - Remark',
  `new_client_list_minites` decimal(5,0) DEFAULT NULL COMMENT '[2023-12-28 棄用]New Client list - Time(mins)',
  `new_client_list_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '[2023-12-28 棄用]New Client list& - Remark',
  `crm_client_but_not_in_daily_call_minutes` decimal(5,0) DEFAULT NULL COMMENT '[2023-12-28 棄用]CRM Client but not in daily call - Time(mins)',
  `crm_client_but_not_in_daily_call_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '[2023-12-28 棄用]CRM Client but not in daily call& - Remark',
  `im_email_minutes` decimal(5,0) DEFAULT NULL COMMENT '[2023-12-28 棄用]IM/Email - Time(mins)',
  `im_email_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '[2023-12-28 棄用]IM/Email& - Remark',
  `translate_time_minutes` decimal(5,0) DEFAULT NULL COMMENT '[2023-12-28 棄用]Translate Time - Time(mins)',
  `translate_time_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '[2023-12-28 棄用]Translate Time& - Remark',
  `warehouse_office_affair_minutes` decimal(5,0) DEFAULT NULL COMMENT '[2023-12-28 棄用]Warehouse/Office Affair - Time(mins)',
  `warehouse_office_affair_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '[2023-12-28 棄用]Warehouse/Office Affair& - Remark',
  `others_work_minutes` decimal(5,0) DEFAULT NULL COMMENT '[2023-12-28 棄用]Others work - Time(mins)',
  `others_work_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '[2023-12-28 棄用]Others work& - Remark',
  `comment_and_recommendation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '[2023-12-28 棄用]Comment and Recommendation',
  `visit_minutes` decimal(5,0) DEFAULT NULL COMMENT '拜訪時長(分鐘)',
  `visit_start_time` time DEFAULT NULL COMMENT '拜訪開始時間',
  `visit_end_time` time DEFAULT NULL COMMENT '拜訪結束時間',
  `start_time` time DEFAULT NULL COMMENT '開始時間',
  `end_time` time DEFAULT NULL COMMENT '結束時間',
  `report_date` date NOT NULL COMMENT '建檔日期',
  `sales_leads` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '銷售線索[簽呈：2411040224，大陸用]',
  `sources_of_investment_leads` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '招商線索資料來源[簽呈：2411040224，大陸用]',
  `desire_to_call` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '電話意願[簽呈：2411040224，大陸用]',
  `approved_wechat_join` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加微成功[簽呈：2411040224，大陸用]',
  `call_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '電訪接通/無效電訪[簽呈：2411040224，大陸用]',
  `explanation_date` date DEFAULT NULL COMMENT '講解日期[簽呈：2411040224，大陸用]',
  `lecturer_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '講解人-姓名[簽呈：2411040224，大陸用]',
  `lecturer_employee_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '講解人-員工編號[簽呈：2411040224，大陸用]',
  `inviter_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邀約人-姓名[簽呈：2411040224，大陸用]',
  `inviter_employee_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邀約人-員工編號[簽呈：2411040224，大陸用]',
  `inviation_channel` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邀約渠道[簽呈：2411040224，大陸用]',
  `explanation_minutes` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '講解時長(分鐘)[簽呈：2411040224，大陸用]',
  `explanation_content` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'K大講解內容[簽呈：2411040224，大陸用]',
  `case_record` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '案件紀錄(K大)[簽呈：2411040224，大陸用]',
  `lecturer_user_id` int DEFAULT NULL COMMENT '講解人UserId[簽呈：2411040224，大陸用]',
  `inviter_user_id` int DEFAULT NULL COMMENT '邀約人UserId[簽呈：2411040224，大陸用]',
  `attachment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '附件：[簽呈：2412090050，海外用]',
  `is_invited_k_meeting` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '是否邀約K大[簽呈:BPM-25060508331, 台灣/海外用]',
  `duration_in_minutes` int DEFAULT NULL COMMENT '講解分鐘數[簽呈: BPM-25060508331, 台灣/海外用]',
  `visit_record_company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord公司全名[簽呈：BPM-25112034747]',
  `visit_record_sign_in_date` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord簽到時間[簽呈：BPM-25112034747]',
  `visit_record_sign_out_date` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord簽退時間[簽呈：BPM-25112034747]',
  `visit_record_sign_in_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord簽到地址[簽呈：BPM-25112034747]',
  `visit_record_sign_out_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord簽退地址[簽呈：BPM-25112034747]',
  `visit_record_visit_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord拜訪時長[簽呈：BPM-25112034747]',
  `visit_record_longitude` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord經度[簽呈：BPM-25112034747]',
  `visit_record_latitude` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord緯度[簽呈：BPM-25112034747]',
  `visit_record_sign_out_longitude` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord簽退經度[簽呈：BPM-25112034747]',
  `visit_record_sign_out_latitude` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord簽退緯度[簽呈：BPM-25112034747]',
  `visit_record_visit_object_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'VisitRecord拜訪對象地址[簽呈：BPM-25112034747]',
  `visit_record_door_picture` json DEFAULT NULL COMMENT 'VisitRecord門牌照[簽呈：BPM-25111934524]',
  `reserve_for_k_online_users_8min` int DEFAULT NULL COMMENT 'K大預約表-K大參會人上線有8分鐘[簽呈：BPM-26020306054]',
  `reserve_for_k_meeting_time` datetime DEFAULT NULL COMMENT 'K大預約表-會議日期[簽呈：BPM-26020306054]',
  `reserve_for_k_attendee_online_minutes` int DEFAULT NULL COMMENT 'K大預約參會人-上线分钟数[簽呈：BPM-26020306054]',
  `reserve_for_k_attendee_meeting_time` datetime DEFAULT NULL COMMENT 'K大預約參會人-会议日期(计算)[簽呈：BPM-26020306054]',
  `feedback` text COLLATE utf8mb4_unicode_ci COMMENT '追蹤紀錄-心得',
  `customer_area` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '追蹤紀錄-客戶所屬資料區域（提示)',
  `product_item_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '追蹤紀錄-商機明細-產品-產品項目分類',
  `estimated_quantity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '追蹤紀錄-商機明細-產品-預估數量',
  `come_from` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0' COMMENT '從哪個CRM來：TW、CN',
  `is_show` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`),
  KEY `lis_show` (`lecturer_user_id`,`is_show`),
  KEY `iis_show` (`inviter_user_id`,`is_show`),
  KEY `liis_show` (`lecturer_user_id`,`inviter_user_id`,`is_show`),
  KEY `elis_show` (`explanation_date`,`lecturer_user_id`,`is_show`),
  KEY `eiis_show` (`explanation_date`,`inviter_user_id`,`is_show`),
  KEY `eliis_show` (`explanation_date`,`lecturer_user_id`,`inviter_user_id`,`is_show`),
  KEY `d_index` (`daily_report_for_sales_id`),
  KEY `dis` (`daily_report_for_sales_id`,`is_show`),
  KEY `daily_report_for_sales_detail_come_from_index` (`come_from`),
  KEY `cr` (`come_from`,`report_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2265706 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工作日報管理-每日報表(業務)-批示記錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
