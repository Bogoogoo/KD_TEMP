-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  程序 als.GetHasAIPermissionUserList 結構
DROP PROCEDURE IF EXISTS `GetHasAIPermissionUserList`;
DELIMITER //
CREATE PROCEDURE `GetHasAIPermissionUserList`()
    COMMENT '取得擁有AI稽核權限人員清單'
BEGIN
SELECT
    pd.id AS department_id,
    u.id AS user_id,
    pd.ch_name AS department_name,
    u.name AS user_name,
    -- 使用條件聚合 (Conditional Aggregation) 進行透視 (Pivot)
    MAX(CASE WHEN pi.ch_name = 'K大邀約稽核' THEN 'K大邀約稽核' ELSE NULL END) AS 'K大邀約稽核',
    MAX(CASE WHEN pi.ch_name = 'K大會議稽核' THEN 'K大會議稽核' ELSE NULL END) AS 'K大會議稽核',
    MAX(CASE WHEN pi.ch_name = 'K大展館稽核' THEN 'K大展館稽核' ELSE NULL END) AS 'K大展館稽核',
    MAX(CASE WHEN pi.ch_name = 'K大外勤稽核' THEN 'K大外勤稽核' ELSE NULL END) AS 'K大外勤稽核',
    MAX(CASE WHEN pi.ch_name = '稽核規則設定' THEN '稽核規則設定' ELSE NULL END) AS '稽核規則設定'
FROM user u
LEFT JOIN permission_setting ps ON u.permission_setting_id = ps.id
LEFT JOIN permission_department pd ON pd.id = ps.department_id
CROSS JOIN
    -- 確保 JSON_TABLE 的輸入是有效的 JSON 陣列
    JSON_TABLE(
        CASE 
            WHEN ps.item_id_data IS NULL OR ps.item_id_data = '' 
            THEN '[]' 
            ELSE ps.item_id_data 
        END,
        '$[*]' COLUMNS (
            item_id INT PATH '$.item_id'
        )
    ) AS jt
INNER JOIN
    permission_item pi ON jt.item_id = pi.id
WHERE
    -- 條件 1: user.status = 2
    u.status = 2
    
    -- 條件 2a: permission_setting.is_show = 1 
    AND ps.is_show = 1
    -- 條件 2b: category_id_data 陣列中包含數字 9
    AND JSON_CONTAINS(ps.category_id_data, '9') 
    
    -- 條件 3a: permission_item.is_show = 1
    AND pi.is_show = 1
    -- 條件 3b: permission_item.category_id = 9
    AND pi.category_id = 9
    -- 效率優化：只處理我們關心的稽核項目
    AND pi.ch_name IN ('K大邀約稽核', 'K大會議稽核', 'K大展館稽核', 'K大外勤稽核', '稽核規則設定')
GROUP BY
    u.id, u.name
ORDER BY
    u.id;
END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
