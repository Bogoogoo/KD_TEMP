-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_options 結構
DROP TABLE IF EXISTS `complaint_options`;
CREATE TABLE IF NOT EXISTS `complaint_options` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主鍵',
  `field_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '欄位名稱',
  `option_value` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '選項值',
  `stage_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '關卡類型：main=主流程/branch=附屬流程（僅 field_name=stage 使用；NULL=非 stage 選項或未設定）',
  `sort_order` int NOT NULL DEFAULT '0' COMMENT '排序',
  `relations` json DEFAULT NULL COMMENT '關聯資料（JSON），如 type_analysis2 子選項、對應權責單位等',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否啟用：0=否 1=是',
  `created_at` timestamp NULL DEFAULT (now()) COMMENT '建立時間',
  PRIMARY KEY (`id`),
  KEY `idx_field` (`field_name`),
  KEY `idx_field_active` (`field_name`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴選項設定';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
