-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.ha_translate_subtitle 結構
DROP TABLE IF EXISTS `ha_translate_subtitle`;
CREATE TABLE IF NOT EXISTS `ha_translate_subtitle` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `source_language` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '翻譯前語系',
  `target_language` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '翻譯後語系',
  `status` tinyint NOT NULL COMMENT '6:waiting_upload, 5:uploading, 4:failed, 3:completed, 2:processing, 1:transcribing, 0:queueing',
  `source` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'user' COMMENT '來源',
  `file_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '媒體檔案名稱',
  `transcription_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '轉錄服務ID',
  `transcription_list` longtext COLLATE utf8mb4_unicode_ci COMMENT '逐字稿內容',
  `file_duration` int DEFAULT NULL COMMENT '媒體內容時長(秒)',
  `file_path` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '檔案路徑',
  `summary` json DEFAULT NULL COMMENT '摘要資訊',
  `cost` tinyint NOT NULL COMMENT '任務費用NT',
  `created_id` int NOT NULL COMMENT '建立任務的使用者 ID',
  `updated_id` int NOT NULL COMMENT '最後更新任務的使用者 ID',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否顯示',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `subtitle` json DEFAULT NULL,
  `speaker_labels` tinyint NOT NULL DEFAULT '0' COMMENT '多少位發言者(講解者+客戶)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=202 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='多國字幕翻譯';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
