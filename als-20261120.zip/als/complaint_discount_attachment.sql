-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.complaint_discount_attachment 結構
DROP TABLE IF EXISTS `complaint_discount_attachment`;
CREATE TABLE IF NOT EXISTS `complaint_discount_attachment` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '附件ID',
  `complaint_id` int unsigned NOT NULL COMMENT '關聯 complaint.id',
  `file_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '檔案類型：image/video',
  `file_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '檔案URL',
  `file_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原始檔名',
  `file_size` int unsigned DEFAULT NULL COMMENT '檔案大小(bytes)',
  `created_by` int NOT NULL COMMENT '建立者 user.id',
  `updated_by` int DEFAULT NULL COMMENT '更新者 user.id',
  `created_at` datetime DEFAULT NULL COMMENT '建立時間（建立時由後端帶入 Carbon::now）',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新時間（DB 維護 CURRENT_TIMESTAMP）',
  `deleted_at` datetime DEFAULT NULL COMMENT '軟刪除時間',
  PRIMARY KEY (`id`),
  KEY `idx_discount_attachment_complaint_id` (`complaint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客訴折讓附件';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
