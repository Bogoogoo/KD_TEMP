-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.permission_button 結構
DROP TABLE IF EXISTS `permission_button`;
CREATE TABLE IF NOT EXISTS `permission_button` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ch_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 正在傾印表格  als.permission_button 的資料：~7 rows (近似值)
DELETE FROM `permission_button`;
INSERT INTO `permission_button` (`id`, `ch_name`, `language_id`, `created_at`, `updated_at`) VALUES
	(1, '新增', 4, '2020-03-17 13:04:05', '2020-07-15 00:51:54'),
	(2, '修改', 5, '2020-03-17 13:04:05', '2020-07-15 00:51:55'),
	(3, '刪除', 6, '2020-03-17 13:04:05', '2020-07-15 00:51:56'),
	(4, '匯入', 7, '2020-03-17 13:04:05', '2020-07-15 00:51:56'),
	(5, '匯出', 8, '2020-03-17 13:04:05', '2020-07-15 00:51:57'),
	(6, '預覽', 9, '2020-03-17 13:04:05', '2020-07-15 00:51:57'),
	(7, '搜尋', 10, '2020-03-17 13:04:05', '2020-07-15 00:51:57');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
