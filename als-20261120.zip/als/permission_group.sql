-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.permission_group 結構
DROP TABLE IF EXISTS `permission_group`;
CREATE TABLE IF NOT EXISTS `permission_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `area_id` smallint NOT NULL,
  `ch_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `is_show` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 正在傾印表格  als.permission_group 的資料：~10 rows (近似值)
DELETE FROM `permission_group`;
INSERT INTO `permission_group` (`id`, `area_id`, `ch_name`, `language_id`, `is_show`, `created_at`, `updated_at`) VALUES
	(1, 1, '董事長室', 75, 1, '2020-03-24 14:26:53', '2020-07-21 00:29:25'),
	(2, 1, '營運單位', 87, 1, '2020-03-24 14:26:53', '2020-07-15 00:52:28'),
	(3, 1, '管理單位', 88, 1, '2020-03-24 14:26:53', '2020-07-15 00:52:29'),
	(4, 1, '生產單位', 89, 1, '2020-03-24 14:26:53', '2020-07-15 00:52:29'),
	(5, 1, '研發單位', 90, 0, '2020-03-24 14:26:53', '2024-12-06 01:46:27'),
	(6, 1, '採購單位', 91, 1, '2020-03-24 14:26:53', '2020-07-15 00:52:30'),
	(7, 1, '稽核室', 92, 1, '2020-03-24 14:26:53', '2020-07-15 00:52:30'),
	(8, 3, '大陸營運單位', 368, 1, '2020-03-24 14:26:53', '2022-01-12 01:20:29'),
	(9, 1, '規劃單位', 874, 1, '2024-08-05 10:25:40', '2024-08-05 02:26:27'),
	(10, 1, '資訊單位', 892, 1, '2024-08-20 08:05:36', '2024-08-20 00:07:08');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
