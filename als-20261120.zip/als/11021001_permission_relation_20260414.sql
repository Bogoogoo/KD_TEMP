-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 移除臨時表格，並建立最終檢視結構
DROP TABLE IF EXISTS `11021001_permission_relation_20260414`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `11021001_permission_relation_20260414` AS select distinct `A`.`id` AS `user_id`,`A`.`name` AS `user_name`,`A`.`account` AS `user_account`,`A`.`permission_setting_id` AS `permission_setting_id`,`S`.`setting_name` AS `setting_name`,`S`.`department_id` AS `department_id`,`D`.`ch_name` AS `dep_name`,`S`.`title_id` AS `title_id`,`T`.`ch_name` AS `title_name`,`jt_a`.`org_id_a` AS `org_id_a`,`t_a`.`ch_name` AS `org_name_a`,`jt_b`.`org_id_b` AS `org_id_b`,`t_b`.`ch_name` AS `org_name_b`,(case when (`ST`.`Team` = `T`.`ch_name`) then NULL else `ST`.`Team` end) AS `setting_Team` from ((((((((`user` `A` left join `permission_setting` `S` on((`A`.`permission_setting_id` = `S`.`id`))) left join `permission_department` `D` on((`S`.`department_id` = `D`.`id`))) left join `permission_title` `T` on((`S`.`title_id` = `T`.`id`))) left join json_table(`S`.`organization_a_id`, '$[*]' columns (`org_id_a` int path '$')) `jt_a` on((1 = 1))) left join `permission_organization_a` `t_a` on((`jt_a`.`org_id_a` = `t_a`.`id`))) left join json_table(`S`.`organization_b_id`, '$[*]' columns (`org_id_b` int path '$')) `jt_b` on((1 = 1))) left join `permission_organization_b` `t_b` on((`jt_b`.`org_id_b` = `t_b`.`id`))) left join (select `t`.`id` AS `id`,`t`.`setting_name` AS `setting_name`,(case when ((right(json_unquote(json_extract(`t`.`j_arr`,'$[0]')),1) = '部') and (right(json_unquote(json_extract(`t`.`j_arr`,'$[1]')),1) = '課')) then json_unquote(json_extract(`t`.`j_arr`,'$[2]')) when (right(json_unquote(json_extract(`t`.`j_arr`,'$[0]')),1) = '課') then json_unquote(json_extract(`t`.`j_arr`,'$[1]')) else NULL end) AS `Team` from (select `S`.`id` AS `id`,`S`.`setting_name` AS `setting_name`,cast(concat('["',replace(`S`.`setting_name`,'-','","'),'"]') as json) AS `j_arr` from `permission_setting` `S`) `t`) `ST` on((`S`.`id` = `ST`.`id`)))
;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
