-- --------------------------------------------------------
-- 主機:                           192.168.1.80
-- 伺服器版本:                        8.0.23 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.uniforms_receive 結構
DROP TABLE IF EXISTS `uniforms_receive`;
CREATE TABLE IF NOT EXISTS `uniforms_receive` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `catelog_id` int NOT NULL COMMENT '目錄ID',
  `user_id` int NOT NULL DEFAULT '0' COMMENT '使用者ID',
  `amount` int NOT NULL COMMENT '數量',
  `applicant` int NOT NULL COMMENT '填寫人',
  `small_id` int NOT NULL COMMENT '領取倉庫',
  `receive_type_id` int DEFAULT NULL COMMENT '領取類型ID',
  `behavior_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '領取狀態(1,2,3)',
  `change_price` smallint DEFAULT NULL COMMENT '更換金額(receive_type_id=3 or 4)',
  `cancel_user` int DEFAULT NULL COMMENT '取消人',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否顯示',
  `memo` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '備註',
  `receive_date` date NOT NULL COMMENT '領取日期',
  `must_pay` smallint DEFAULT '0' COMMENT '應繳交費用',
  `created_at` datetime NOT NULL COMMENT '建立日期',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日期',
  PRIMARY KEY (`id`),
  KEY `uniforms_list_id` (`catelog_id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `applicant` (`applicant`),
  KEY `FK_uniforms_receive_uniforms_receive_type` (`receive_type_id`),
  KEY `warehouse_id` (`small_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='制服 - 領取紀錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
