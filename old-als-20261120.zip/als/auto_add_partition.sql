-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  事件 als.auto_add_partition 結構
DROP EVENT IF EXISTS `auto_add_partition`;
DELIMITER //
CREATE EVENT `auto_add_partition` ON SCHEDULE EVERY 1 YEAR STARTS '2022-12-09 12:00:00' ON COMPLETION PRESERVE ENABLE COMMENT '自動建立partition table' DO BEGIN
	DECLARE _index INT DEFAULT 0;
	DECLARE _nextYear YEAR; 
	DECLARE _tableName TEXT DEFAULT '';
	DECLARE _option TEXT DEFAULT '';
	DECLARE _tableNames CURSOR FOR
		SELECT 'als_opm_details' AS `tableName`, 'year' AS `option` UNION
		SELECT 'als_opm_details_cn' AS `tableName`, 'year' AS `option` UNION
		SELECT 'als_opm_details_hk' AS `tableName`, 'year' AS `option` UNION
		SELECT 'als_opm_details_mys' AS `tableName`, 'year' AS `option` UNION
		SELECT 'als_opm_details_sg' AS `tableName`, 'year' AS `option` UNION
		SELECT 'als_monthly_sales_detail' AS `tableName`, 'month' AS `option` UNION
		SELECT 'als_monthly_sales_detail_cn' AS `tableName`, 'month' AS `option` UNION
		SELECT 'als_monthly_sales_detail_hk' AS `tableName`, 'month' AS `option` UNION
		SELECT 'als_monthly_sales_detail_my' AS `tableName`, 'month' AS `option` UNION
		SELECT 'als_monthly_sales_detail_sg' AS `tableName`, 'month' AS `option`;

	SET _nextYear = YEAR(DATE_ADD(NOW(), INTERVAL 1 YEAR));
	
	OPEN _tableNames;
	WHILE _index < 10 DO
		FETCH _tableNames INTO _tableName, _option;
		CALL add_partition(_tableName, _nextYear, _option);
		SET _index = _index + 1;
	END WHILE;
END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
