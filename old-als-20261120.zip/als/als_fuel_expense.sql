-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_fuel_expense 結構
DROP TABLE IF EXISTS `als_fuel_expense`;
CREATE TABLE IF NOT EXISTS `als_fuel_expense` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `name` int NOT NULL COMMENT '姓名',
  `tank_capacity` int NOT NULL COMMENT '油箱容量 als_tank_capacity.id(20191022)',
  `number_plate` varchar(10) NOT NULL COMMENT '車號',
  `car` varchar(30) NOT NULL COMMENT '車種',
  `car_year` int NOT NULL COMMENT '年份',
  `capacity` int NOT NULL COMMENT 'CC數',
  `oil_products` varchar(10) NOT NULL COMMENT '油品',
  `not_usual` int NOT NULL COMMENT '非一般區域',
  `apply_date` date NOT NULL COMMENT '請領日期',
  `s_mileage` int NOT NULL COMMENT '月初里程',
  `e_mileage` int NOT NULL COMMENT '月底里程',
  `mileage` int NOT NULL COMMENT '本月里程',
  `subsidy_money` decimal(6,4) NOT NULL COMMENT '平均油價x補貼_1x補貼_2',
  `average_oil` decimal(6,3) NOT NULL COMMENT '平均油價',
  `auxiliary_highest` int NOT NULL DEFAULT '0' COMMENT '最高輔助',
  `total_1` int NOT NULL COMMENT '合計_自動結算金額',
  `total_no_tax` int NOT NULL,
  `total_tax` int NOT NULL,
  `total_2` int NOT NULL DEFAULT '0' COMMENT '合計_審核過後金額',
  `travel` int NOT NULL COMMENT '出遊',
  `liter` int NOT NULL COMMENT '追扣出遊容量',
  `apply_total` int NOT NULL DEFAULT '0' COMMENT '請領金額',
  `apply_orther` int NOT NULL DEFAULT '0' COMMENT '其它金額',
  `stop_capacity_unusual` int NOT NULL DEFAULT '0' COMMENT '容量異常',
  `abnormal_inconsistent` int NOT NULL COMMENT '上月不符情況',
  `no_data` int NOT NULL DEFAULT '0' COMMENT '無上個月資料/=1',
  `auxiliary_selection` int NOT NULL DEFAULT '0' COMMENT '輔助選擇',
  `memo` varchar(100) DEFAULT NULL COMMENT '備註',
  `check_personnel` varchar(5) DEFAULT NULL COMMENT '稽核人員',
  `update_data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  `calculated` int NOT NULL DEFAULT '0' COMMENT '已計算',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  `travel_input_for_liter` int NOT NULL DEFAULT '0' COMMENT '出遊計算輸入公升數',
  `travel_input_for_average_oil` decimal(6,3) NOT NULL DEFAULT '0.000' COMMENT '出遊計算輸入平均油價',
  `travel_input_for_on_the_job` int NOT NULL DEFAULT '0' COMMENT '出遊計算輸入在職天數',
  `travel_input_for_base_day` int NOT NULL DEFAULT '0' COMMENT '出遊計算輸入基準天數',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3812 DEFAULT CHARSET=utf8 COMMENT='油費登錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
