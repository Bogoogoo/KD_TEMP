-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_details_cn 結構
DROP TABLE IF EXISTS `als_opm_details_cn`;
CREATE TABLE IF NOT EXISTS `als_opm_details_cn` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `customer_id` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '買方代號',
  `money` decimal(20,2) NOT NULL COMMENT '未稅本位幣',
  `materials_id` varchar(20) NOT NULL COMMENT '物料',
  `trading_volume` float NOT NULL COMMENT '交貨數量',
  `sell_date` date NOT NULL COMMENT '交易日期',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `del` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`,`customer_id`,`sell_date`) USING BTREE,
  KEY `customer_id` (`customer_id`),
  KEY `sell_date` (`sell_date`),
  KEY `del` (`del`)
) ENGINE=InnoDB AUTO_INCREMENT=916582 DEFAULT CHARSET=utf8 COMMENT='交易明細(大陸)(20200203)'
/*!50100 PARTITION BY RANGE (year(`sell_date`))
(PARTITION y2013 VALUES LESS THAN (2014) ENGINE = InnoDB,
 PARTITION y2014 VALUES LESS THAN (2015) ENGINE = InnoDB,
 PARTITION y2015 VALUES LESS THAN (2016) ENGINE = InnoDB,
 PARTITION y2016 VALUES LESS THAN (2017) ENGINE = InnoDB,
 PARTITION y2017 VALUES LESS THAN (2018) ENGINE = InnoDB,
 PARTITION y2018 VALUES LESS THAN (2019) ENGINE = InnoDB,
 PARTITION y2019 VALUES LESS THAN (2020) ENGINE = InnoDB,
 PARTITION y2020 VALUES LESS THAN (2021) ENGINE = InnoDB,
 PARTITION y2021 VALUES LESS THAN (2022) ENGINE = InnoDB,
 PARTITION y2022 VALUES LESS THAN (2023) ENGINE = InnoDB,
 PARTITION y2023 VALUES LESS THAN (2024) ENGINE = InnoDB,
 PARTITION y2024 VALUES LESS THAN (2025) ENGINE = InnoDB,
 PARTITION y2025 VALUES LESS THAN (2026) ENGINE = InnoDB,
 PARTITION y2026 VALUES LESS THAN (2027) ENGINE = InnoDB,
 PARTITION ymax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
