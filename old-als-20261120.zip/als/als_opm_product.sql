-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_product 結構
DROP TABLE IF EXISTS `als_opm_product`;
CREATE TABLE IF NOT EXISTS `als_opm_product` (
  `customer_id` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客戶編號',
  `k3_number` decimal(9,2) NOT NULL COMMENT '加總 - 數量',
  `k3_account` int NOT NULL COMMENT '加總 - 金額',
  `k4_number` decimal(9,2) NOT NULL COMMENT '加總 - 數量',
  `k4_account` int NOT NULL COMMENT '加總 - 金額',
  `k6_number` decimal(9,2) NOT NULL COMMENT '加總 - 數量',
  `k6_account` int NOT NULL COMMENT '加總 - 金額',
  `kd_number` decimal(9,2) NOT NULL COMMENT '加總 - 數量',
  `kd_account` int NOT NULL COMMENT '加總 - 金額',
  `kf_number` decimal(9,2) NOT NULL COMMENT '加總 - 數量',
  `kf_account` int NOT NULL COMMENT '加總 - 金額',
  `pp_number` decimal(9,2) NOT NULL COMMENT 'PP加總 - 金額',
  `pp_account` int NOT NULL COMMENT 'PP加總 - 數量',
  `cabinet_number` decimal(9,2) NOT NULL COMMENT '定製櫃加總 - 金額',
  `cabinet_account` int NOT NULL COMMENT '定製櫃加總 - 數量',
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='產品線統計';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
