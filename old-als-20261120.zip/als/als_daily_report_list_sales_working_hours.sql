-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_report_list_sales_working_hours 結構
DROP TABLE IF EXISTS `als_daily_report_list_sales_working_hours`;
CREATE TABLE IF NOT EXISTS `als_daily_report_list_sales_working_hours` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `work_list_id` int unsigned NOT NULL COMMENT '業務日報編號(20191113)',
  `crm_account_id` int unsigned NOT NULL COMMENT '該業務CRM Account ID',
  `work_time_for_start` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0800' COMMENT '上班時間',
  `visit_time_for_first_morning` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '拜訪上午第一家時間',
  `visit_time_for_last_morning` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '拜訪上午最後一家時間',
  `visit_time_for_first_afternoon` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '拜訪下午第一家時間',
  `visit_time_for_last_afternoon` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '拜訪下午最後一家時間',
  `work_time_for_end` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '1720' COMMENT '下班時間',
  `minutes_for_morning` int NOT NULL DEFAULT '0' COMMENT '上班至第一家時間',
  `minutes_for_afternoon` int unsigned NOT NULL DEFAULT '0' COMMENT '中午休息時間(下午第一家-上午最後一家)',
  `minutes_for_night` int NOT NULL DEFAULT '0' COMMENT '最後一家至下班時間(下午最後一家-下班時間)',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `work_list_id` (`work_list_id`) USING BTREE,
  KEY `CRM_branch_id` (`crm_account_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=56245 DEFAULT CHARSET=utf8 COMMENT='每日報表業務工作時段紀錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
