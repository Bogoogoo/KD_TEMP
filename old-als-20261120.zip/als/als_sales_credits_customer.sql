-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_sales_credits_customer 結構
DROP TABLE IF EXISTS `als_sales_credits_customer`;
CREATE TABLE IF NOT EXISTS `als_sales_credits_customer` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `customer_id` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客戶編號',
  `customer_group` varchar(5) NOT NULL COMMENT '客戶價格群組',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '名稱',
  `ein` varchar(15) NOT NULL COMMENT '統一編號',
  `credit_control` varchar(10) NOT NULL COMMENT '信用管制說明',
  `performance` varchar(50) NOT NULL COMMENT '性能分類說明',
  `customer_credit` varchar(20) NOT NULL COMMENT '客戶信用群組說明',
  `postal_code` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '郵遞區號als_opm_area.postal_code(20191009)',
  `monthly_s` date DEFAULT NULL COMMENT '月結起始日',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  KEY `postal_code` (`postal_code`),
  KEY `monthly_s` (`monthly_s`),
  KEY `del` (`del`)
) ENGINE=InnoDB AUTO_INCREMENT=26357 DEFAULT CHARSET=utf8 COMMENT='客戶信用額度OPM客戶主檔';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
