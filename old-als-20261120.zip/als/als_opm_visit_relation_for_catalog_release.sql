-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_visit_relation_for_catalog_release 結構
DROP TABLE IF EXISTS `als_opm_visit_relation_for_catalog_release`;
CREATE TABLE IF NOT EXISTS `als_opm_visit_relation_for_catalog_release` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `als_opm_visit_id` int NOT NULL COMMENT '參訪紀錄ID',
  `als_catalog_for_release_id` int NOT NULL COMMENT '展示館發放型錄ID',
  `als_catalog_reason_for_release_id` int NOT NULL COMMENT '展示館發放原因ID',
  `del` tinyint(1) unsigned zerofill NOT NULL DEFAULT '0' COMMENT '是否刪除',
  `creator` int NOT NULL COMMENT '建立者',
  `updater` int DEFAULT NULL COMMENT '更新者',
  `creation_datetime` timestamp NOT NULL COMMENT '建立時間',
  `modify_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '變更時間',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `creator` (`creator`) USING BTREE,
  KEY `updater` (`updater`) USING BTREE,
  KEY `del` (`del`) USING BTREE,
  KEY `als_opm_visit_id` (`als_opm_visit_id`) USING BTREE,
  KEY `als_catalog_for_release_id` (`als_catalog_for_release_id`) USING BTREE,
  KEY `als_catalog_reason_for_release_id` (`als_catalog_reason_for_release_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=406 DEFAULT CHARSET=utf8 COMMENT='參訪紀錄與展示館型錄與展示館發放原因關聯資料';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
