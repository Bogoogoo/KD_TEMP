-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_warehouse_paint 結構
DROP TABLE IF EXISTS `als_warehouse_paint`;
CREATE TABLE IF NOT EXISTS `als_warehouse_paint` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '料號',
  `formula` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '配方',
  `batch` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '批次',
  `total` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '撥補總數',
  `Inspection` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '檢貨',
  `quantity` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '檢貨數量',
  `del` tinyint(1) NOT NULL,
  `import_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `times` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '次數',
  `month` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '月份',
  `date` date DEFAULT NULL COMMENT '出口日',
  `ExpectedDate` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '預計到貨日',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
