-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_inventory 結構
DROP TABLE IF EXISTS `als_inventory`;
CREATE TABLE IF NOT EXISTS `als_inventory` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `list_id` int unsigned NOT NULL COMMENT 'list流水號',
  `time_id` int NOT NULL COMMENT '盤點批次',
  `warehouse_id` int unsigned NOT NULL COMMENT '分公司編號(als_inventory_wh 20200722)',
  `inventory_id` varchar(20) NOT NULL COMMENT '列管編號',
  `department_id` int unsigned NOT NULL COMMENT '部門編號(als_inventory_department 20200722)',
  `type_id` int unsigned NOT NULL COMMENT '資產類型(als_inventory_type 20200722)',
  `sap_id` varchar(20) DEFAULT NULL COMMENT '資產編號',
  `sap_id2` int unsigned DEFAULT NULL COMMENT '實盤數(20191120)',
  `name` text NOT NULL COMMENT '資產名稱',
  `get_date` date DEFAULT NULL COMMENT '取得日期',
  `money` int unsigned NOT NULL COMMENT '金額',
  `vendor` varchar(50) NOT NULL COMMENT '廠商',
  `location_id` int NOT NULL COMMENT '資產位置(als_inventory_location 20200722)',
  `keeper_id` int NOT NULL COMMENT '保管人',
  `system_ok` int NOT NULL DEFAULT '0' COMMENT '系統盤點完成',
  `ok` int NOT NULL DEFAULT '0' COMMENT '盤點完成 (1:是 0:否 20191204)',
  `inventory_time` datetime DEFAULT NULL COMMENT '盤點時間',
  `note` text COMMENT '備註',
  `checker_id` int DEFAULT NULL COMMENT '盤點人ID',
  `time` datetime DEFAULT NULL COMMENT '盤點時間',
  `del` tinyint(1) NOT NULL DEFAULT '0',
  `improve` varchar(255) DEFAULT NULL COMMENT '改善方案',
  PRIMARY KEY (`id`),
  KEY `time_id` (`time_id`),
  KEY `list_id` (`list_id`),
  KEY `sap_id` (`sap_id`),
  KEY `sap_id2` (`sap_id2`),
  KEY `location_id` (`location_id`),
  KEY `system_ok` (`system_ok`),
  KEY `del` (`del`),
  KEY `checker_id` (`checker_id`),
  KEY `type_id` (`type_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `department_id` (`department_id`),
  KEY `keeper_id` (`keeper_id`)
) ENGINE=InnoDB AUTO_INCREMENT=124585 DEFAULT CHARSET=utf8 COMMENT='盤點明細(20191121)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
