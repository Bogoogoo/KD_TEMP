-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  程序 als.init_als_opm_visit_relation_for_catalog_visit_item 結構
DROP PROCEDURE IF EXISTS `init_als_opm_visit_relation_for_catalog_visit_item`;
DELIMITER //
CREATE PROCEDURE `init_als_opm_visit_relation_for_catalog_visit_item`()
BEGIN
	DECLARE _index INT DEFAULT 0;
	DECLARE _finished INT DEFAULT 0;
	DECLARE _count INT DEFAULT 0;
	
	DECLARE _exist INT DEFAULT 1;
	DECLARE _has_insert INT DEFAULT 0;
	DECLARE _id INT;
	DECLARE _t2_1 VARCHAR(10);
	DECLARE _t2_2 VARCHAR(10);
	DECLARE _t2_3 VARCHAR(10);
	DECLARE _t2_4 VARCHAR(10);
	DECLARE _t2_6 VARCHAR(10);
	DECLARE _t2_7 VARCHAR(10);
	DECLARE _t2_8 VARCHAR(10);
	DECLARE _t2_9 VARCHAR(10);
	DECLARE _t2_10 VARCHAR(10);
	DECLARE _t2_11 VARCHAR(10);
	DECLARE _t2_12 VARCHAR(10);
	DECLARE _created_at VARCHAR(50);
	
	-- 找出 t2_1....t2_12 有值的紀錄
	DECLARE _cursors 
		CURSOR FOR
			SELECT `id`, LOWER(`t2_1`), LOWER(`t2_2`), LOWER(`t2_3`), LOWER(`t2_4`), LOWER(`t2_6`), 
				LOWER(`t2_7`), LOWER(`t2_8`), LOWER(`t2_9`), LOWER(`t2_10`), LOWER(`t2_11`), LOWER(`t2_12`), 
				CONCAT(`visit_date`, ' 00:00:00') AS `created_at` 
			FROM `als_opm_visit` 
			WHERE
				(`t2_1` IS NOT NULL AND `t2_1` <> '') OR
				(`t2_2` IS NOT NULL AND `t2_2` <> '') OR
				(`t2_3` IS NOT NULL AND `t2_3` <> '') OR
				(`t2_4` IS NOT NULL AND `t2_4` <> '') OR
				(`t2_6` IS NOT NULL AND `t2_6` <> '') OR
				(`t2_7` IS NOT NULL AND `t2_7` <> '') OR
				(`t2_8` IS NOT NULL AND `t2_8` <> '') OR
				(`t2_9` IS NOT NULL AND `t2_9` <> '') OR
				(`t2_10` IS NOT NULL AND `t2_10` <> '') OR
				(`t2_11` IS NOT NULL AND `t2_11` <> '') OR
				(`t2_12` IS NOT NULL AND `t2_12` <> '')
			ORDER BY `id` ASC;
		
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET _finished = 1;
	
	OPEN _cursors;
	
	getData: LOOP 
		FETCH _cursors INTO _id, _t2_1, _t2_2, _t2_3, _t2_4, _t2_6, _t2_7, _t2_8, _t2_9, _t2_10, _t2_11, _t2_12, _created_at;
		
		IF _finished = 1 THEN 
			LEAVE getData;
		END IF;
		
		SET _has_insert = 0;
		
		IF _t2_1 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 1;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 1, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_2 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 2;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 2, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_3 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 3;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 3, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_4 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 4;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 4, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_6 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 6;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 6, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_7 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 7;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 7, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_8 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 8;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 8, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_9 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 9;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 9, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_10 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 10;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 10, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_11 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 11;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 11, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		IF _t2_12 = 'on' THEN
			SELECT COUNT(1) > 0 INTO _exist FROM `als_opm_visit_relation_for_catalog_visit_item` WHERE `del` = 0 AND `als_opm_visit_id` = _id AND `als_catalog_for_visit_item_id` = 12;
		
			IF _exist = false THEN
				INSERT INTO `als_opm_visit_relation_for_catalog_visit_item`(`als_opm_visit_id`, `als_catalog_for_visit_item_id`, `creator`, `created_at`) VALUES 
				(_id, 12, 1, _created_at);
				
				SET _has_insert = _has_insert + 1;
			END IF;
		END IF;
		
		IF _has_insert > 0 THEN
			SET _count = _count + 1;
		END IF;
	END LOOP getData;
	
	CLOSE _cursors;
	
	SELECT _count, _finished;
END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
