-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_visit_ph 結構
DROP TABLE IF EXISTS `als_opm_visit_ph`;
CREATE TABLE IF NOT EXISTS `als_opm_visit_ph` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '客戶代號 SAP ID(202020205)',
  `visit_date` date NOT NULL COMMENT '參訪日期 Visiting date(20200204)',
  `visit_t1` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '展示館 (20200205)',
  `visit_t2` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '倉庫(20200205)',
  `visit_t4` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'K大視訊',
  `company_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '公司名稱 Company name(20200204)',
  `company_phone1` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '電話區碼(20200205)',
  `company_phone2` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '公司電話 TEL(20200204)',
  `company_address` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '客戶公司地址(交辦區域) Company address(20200204)',
  `is_finish_check` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '是否完成普查',
  `area` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '業務區域 Sales area = als_sales_area_level4.id (20200204)',
  `invite_area` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '邀約區域',
  `customer_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '客戶名稱 Contact name(20200204)',
  `cell_phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '行動電話 Mobile no(20200204)',
  `inviter` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '邀請人 invited by(20200205)',
  `receptionist` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '接待人員 Received by(20200204)',
  `email` varchar(80) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '客戶信箱Email(20200205)',
  `time1` time NOT NULL COMMENT '接待時間(開始) Time(20200204)',
  `time2` time NOT NULL COMMENT '接待時間(結束) Time(20200204)',
  `amount` int NOT NULL COMMENT '參訪人數 Number of visitors(20200204)',
  `t1` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '設計師 Designer(20200204)',
  `t2` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '木工 Carpenter(20200204)',
  `t3` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '業主Owner(20200204)',
  `t4` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '其他Other(20200204)',
  `t2_1` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '木地板 Item KD flooring(20200204)',
  `t2_2` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '木皮版 Item KD panels(20200204)',
  `note` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '參訪內容 content(20202004)',
  `t3_1` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '木地板(丈量)',
  `measuring_date` date DEFAULT NULL COMMENT '丈量日期  Measurement date(20200205)',
  `duration` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '工期 Construction date(20200204)',
  `site` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '工地 Site address(20200204)',
  `reservation` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '是否預約 Appointment(20200204)',
  `recorder` int NOT NULL COMMENT '登打人員 Key in by(20200204)',
  `updater` int DEFAULT NULL COMMENT '修改紀錄的人(20200205)',
  `create_date` datetime DEFAULT NULL COMMENT '建立時間(20200206)',
  `del_id` int DEFAULT NULL COMMENT '刪除該記錄的人',
  `del` tinyint(1) DEFAULT '0' COMMENT '是否刪除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `customer_id` (`customer_id`),
  KEY `del` (`del`),
  KEY `customer_id_del` (`customer_id`,`del`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='參訪紀錄_菲律賓(20220531), 從 als_opm_visit_sg 複製過來';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
