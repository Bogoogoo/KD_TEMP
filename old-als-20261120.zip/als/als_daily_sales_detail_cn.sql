-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_sales_detail_cn 結構
DROP TABLE IF EXISTS `als_daily_sales_detail_cn`;
CREATE TABLE IF NOT EXISTS `als_daily_sales_detail_cn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bgroup` varchar(50) DEFAULT NULL COMMENT '大群組說明',
  `ed_date` varchar(20) DEFAULT NULL COMMENT '大陸-预计发货日期_A',
  `re_desc` varchar(10) DEFAULT NULL COMMENT '大陸-地区说明_B',
  `buyer` varchar(20) DEFAULT NULL COMMENT '大陸-买方',
  `buyer_desc` varchar(100) DEFAULT NULL COMMENT '买方说明_C',
  `materials_id` varchar(20) DEFAULT NULL COMMENT '物料_E',
  `materials_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物料說明_F',
  `batch` varchar(20) DEFAULT NULL COMMENT '批次_G',
  `trading_volume` varchar(20) DEFAULT NULL COMMENT '交货数量_H',
  `unit_price` varchar(20) DEFAULT NULL COMMENT '单价_I',
  `no_tax_price` varchar(20) DEFAULT NULL COMMENT '未税本位币_J',
  `price` varchar(20) DEFAULT NULL COMMENT '本位币_K',
  `sell_doc_id` varchar(20) DEFAULT NULL COMMENT '销售文件号码_L',
  `industry` varchar(20) DEFAULT NULL COMMENT '行业别_M',
  `requirement` text COMMENT '货品需求_N',
  `deduction_project` varchar(100) DEFAULT NULL COMMENT '扣瑕/专案_O',
  `to_driver` varchar(200) DEFAULT NULL COMMENT 'TO 司机_P',
  `to_warehouse` varchar(100) DEFAULT NULL COMMENT 'TO 仓管_Q',
  `address` varchar(255) DEFAULT NULL COMMENT '送货地址_R',
  `address3` varchar(255) DEFAULT NULL COMMENT '送貨地址3_S',
  `f_name` varchar(50) DEFAULT NULL COMMENT '姓_T',
  `l_name` varchar(255) DEFAULT NULL COMMENT '名_U',
  `shipping_desc` varchar(100) DEFAULT NULL COMMENT '出货点说明_v',
  `invoice_type` varchar(20) DEFAULT NULL COMMENT '发票类型',
  `m_record` varchar(100) DEFAULT NULL COMMENT '修改记录',
  `golden_tax_note` varchar(100) DEFAULT NULL COMMENT '金税注释_Y',
  `tax_address` varchar(100) DEFAULT NULL COMMENT '金税地址_z',
  `tax_number5` varchar(100) DEFAULT NULL COMMENT '税号5_AA',
  `payment_memo` varchar(100) DEFAULT NULL COMMENT '请款单客户备注_AB',
  `create_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建立日期',
  `area_id` varchar(20) DEFAULT '1' COMMENT '區域 1 大陸 2香港 3新加坡',
  `b_group` varchar(20) DEFAULT NULL COMMENT '不分區-帳號能看群組',
  `group_description` varchar(15) DEFAULT NULL COMMENT '客户群组一说明_AC(20191008)',
  `invoice` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '發票抬頭(20211108 h)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5244 DEFAULT CHARSET=utf8 COMMENT='大陸每日銷售明細(20191008)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
