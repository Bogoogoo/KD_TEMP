-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_year 結構
DROP TABLE IF EXISTS `als_opm_year`;
CREATE TABLE IF NOT EXISTS `als_opm_year` (
  `customer_id` varchar(10) NOT NULL COMMENT '客戶代號',
  `range1` varchar(15) NOT NULL COMMENT '級距1',
  `target_p1` float NOT NULL COMMENT '目標%數1',
  `target_m1` int NOT NULL COMMENT '目標金額1',
  `over_p1` float NOT NULL COMMENT '超標%數1',
  `over_m1` int NOT NULL COMMENT '超標金額1',
  `range2` varchar(15) NOT NULL COMMENT '級距2',
  `target_p2` float NOT NULL COMMENT '目標%數2',
  `target_m2` int NOT NULL COMMENT '目標金額2',
  `over_p2` float NOT NULL COMMENT '超標%數2',
  `over_m2` int NOT NULL COMMENT '超標金額2',
  `range3` varchar(15) NOT NULL COMMENT '級距3',
  `target_p3` float NOT NULL COMMENT '目標%數3',
  `target_m3` int NOT NULL COMMENT '目標金額3',
  `over_p3` float NOT NULL COMMENT '超標%數3',
  `over_m3` int NOT NULL COMMENT '超標金額3',
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
