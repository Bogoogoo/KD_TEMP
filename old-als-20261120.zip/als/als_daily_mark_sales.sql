-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_mark_sales 結構
DROP TABLE IF EXISTS `als_daily_mark_sales`;
CREATE TABLE IF NOT EXISTS `als_daily_mark_sales` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `daily_sales_id` int NOT NULL COMMENT '日報流水號',
  `name` int NOT NULL COMMENT '批示人',
  `mark` text NOT NULL COMMENT '批示',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '批閱時間(20191216)',
  `del` int NOT NULL DEFAULT '0' COMMENT '刪除',
  `status` int NOT NULL DEFAULT '0' COMMENT '1:第一次批示狀態 0:未批示過、非批示人 (20191216) *20191226以前批示過的人全部狀態都是1不管是不是第一次、第二次批示',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `daily_sales_id` (`daily_sales_id`)
) ENGINE=InnoDB AUTO_INCREMENT=243167 DEFAULT CHARSET=utf8 COMMENT='業務日報批示狀態(20191119)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
