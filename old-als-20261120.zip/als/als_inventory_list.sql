-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_inventory_list 結構
DROP TABLE IF EXISTS `als_inventory_list`;
CREATE TABLE IF NOT EXISTS `als_inventory_list` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inventory_id` varchar(20) NOT NULL COMMENT '列管代號',
  `warehouse_id` int unsigned NOT NULL COMMENT '分公司代號',
  `department_id` int unsigned NOT NULL COMMENT '管理部門代號',
  `type` int unsigned NOT NULL COMMENT '資產類別',
  `sap_id` varchar(20) DEFAULT NULL COMMENT '固資代號',
  `sap_id2` int unsigned DEFAULT NULL COMMENT '應盤數數量20191108',
  `name` text NOT NULL COMMENT '資產名稱',
  `get_date` date DEFAULT NULL COMMENT '取得日期',
  `money` int unsigned NOT NULL,
  `vendor` varchar(50) NOT NULL COMMENT '廠商',
  `location_id` int unsigned NOT NULL COMMENT '資產位置',
  `keeper_id` int unsigned NOT NULL COMMENT '保管人',
  `creator_id` int unsigned NOT NULL COMMENT '建立者',
  `create_date` datetime NOT NULL COMMENT '建立日期',
  `user_id` int unsigned DEFAULT NULL COMMENT '使用者',
  `note` text NOT NULL COMMENT '備註',
  `del` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `department_id` (`department_id`),
  KEY `sap_id` (`sap_id`,`sap_id2`) USING BTREE,
  KEY `inventory_id` (`inventory_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `sap_id_2` (`sap_id`),
  KEY `sap_id2` (`sap_id2`)
) ENGINE=InnoDB AUTO_INCREMENT=4738 DEFAULT CHARSET=utf8 COMMENT='資產管理(20191121)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
