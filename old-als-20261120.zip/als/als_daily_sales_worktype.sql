-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_sales_worktype 結構
DROP TABLE IF EXISTS `als_daily_sales_worktype`;
CREATE TABLE IF NOT EXISTS `als_daily_sales_worktype` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `work_list_id` int NOT NULL,
  `SalesName` int NOT NULL COMMENT 'als_user.id',
  `worktype` varchar(1110) NOT NULL,
  `before_check` float DEFAULT '0' COMMENT '審核前計算時數',
  `after_check` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '主管審核後計算時數',
  `is_overseas_need` tinyint unsigned DEFAULT '0' COMMENT '是否為海外所需',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `del` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `work_list_id` (`work_list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2876489 DEFAULT CHARSET=utf8 COMMENT='日報查閱(業務)的工作型態(20191108)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
