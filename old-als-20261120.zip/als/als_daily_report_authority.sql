-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_report_authority 結構
DROP TABLE IF EXISTS `als_daily_report_authority`;
CREATE TABLE IF NOT EXISTS `als_daily_report_authority` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creation_name` int NOT NULL COMMENT '建立人',
  `name` int NOT NULL,
  `to_name` int NOT NULL COMMENT '批閱者(20191128)',
  `visible` int NOT NULL COMMENT '1：隱藏/0：可見',
  `is_mark` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否可以批示(0: 否, 1: 是)',
  `time_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '最後修改時間',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  `sales_group` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否從業務群組加入 0 不是  1 是',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `to_name` (`to_name`) USING BTREE,
  KEY `name_to_name_is_mark_del` (`name`,`to_name`,`is_mark`,`del`)
) ENGINE=InnoDB AUTO_INCREMENT=60265 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='日報權限管理(20191128)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
