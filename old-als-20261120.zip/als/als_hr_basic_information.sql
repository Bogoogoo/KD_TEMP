-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_hr_basic_information 結構
DROP TABLE IF EXISTS `als_hr_basic_information`;
CREATE TABLE IF NOT EXISTS `als_hr_basic_information` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `session_id` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' COMMENT 'session_id',
  `country` int NOT NULL COMMENT '國家',
  `name` varchar(20) NOT NULL COMMENT '姓名',
  `birth` date DEFAULT NULL COMMENT '生日',
  `gender` int NOT NULL COMMENT '性別',
  `tel` varchar(20) DEFAULT NULL COMMENT '電話',
  `cell` varchar(20) DEFAULT NULL COMMENT '手機',
  `blood_type` int NOT NULL DEFAULT '0' COMMENT '血型',
  `marriage` int DEFAULT NULL COMMENT '婚姻',
  `moto_license` int DEFAULT NULL COMMENT '機車駕照',
  `car_license` int DEFAULT NULL COMMENT '汽車駕照',
  `identifying` varchar(20) NOT NULL COMMENT '驗證碼',
  `examination_paper` varchar(5) NOT NULL COMMENT '考試卷',
  `m_answer` varchar(50) DEFAULT NULL COMMENT '應試者答案_數學',
  `m_corr_answer` varchar(50) DEFAULT NULL COMMENT '數學正確答案',
  `math_answer` varchar(5) DEFAULT NULL COMMENT '答對題數_數學',
  `e_answer` varchar(50) DEFAULT NULL COMMENT '應試者答案_英文',
  `e_corr_answer` varchar(50) DEFAULT NULL COMMENT '英文正確答案',
  `english_answer` varchar(5) DEFAULT NULL COMMENT '答對題數_英文',
  `test_s` datetime DEFAULT NULL COMMENT '考試開始時間',
  `test_e` datetime DEFAULT NULL COMMENT '考試結束時間',
  `build_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建立時間',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '資料更新時間',
  `question_ids` varchar(255) NOT NULL COMMENT '題目IDs',
  `is_submit_from_admin` tinyint(1) DEFAULT '0' COMMENT '是否由管理者更新資料',
  `comment` varchar(255) DEFAULT NULL COMMENT '備註:紀錄哪位帳號更新此筆資料',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35199 DEFAULT CHARSET=utf8 COMMENT='基本資料';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
