-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_hr_questions_english 結構
DROP TABLE IF EXISTS `als_hr_questions_english`;
CREATE TABLE IF NOT EXISTS `als_hr_questions_english` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `text` mediumtext NOT NULL COMMENT '題目',
  `choice_1` text NOT NULL,
  `choice_1_A` text NOT NULL,
  `choice_1_B` text NOT NULL,
  `choice_1_C` text NOT NULL,
  `choice_1_D` text NOT NULL,
  `choice_1_E` text NOT NULL,
  `choice_1_F` text NOT NULL,
  `choice_1_G` text NOT NULL,
  `choice_1_H` text NOT NULL,
  `choice_2` text NOT NULL,
  `choice_2_A` text NOT NULL,
  `choice_2_B` text NOT NULL,
  `choice_2_C` text NOT NULL,
  `choice_2_D` text NOT NULL,
  `choice_2_E` text NOT NULL,
  `choice_2_F` text NOT NULL,
  `choice_2_G` text NOT NULL,
  `choice_2_H` text NOT NULL,
  `choice_3` text NOT NULL,
  `choice_3_A` text NOT NULL,
  `choice_3_B` text NOT NULL,
  `choice_3_C` text NOT NULL,
  `choice_3_D` text NOT NULL,
  `choice_3_E` text NOT NULL,
  `choice_3_F` text NOT NULL,
  `choice_3_G` text NOT NULL,
  `choice_3_H` text NOT NULL,
  `answer` varchar(15) NOT NULL,
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='英文題庫';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
