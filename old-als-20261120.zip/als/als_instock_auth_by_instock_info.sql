-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_instock_auth_by_instock_info 結構
DROP TABLE IF EXISTS `als_instock_auth_by_instock_info`;
CREATE TABLE IF NOT EXISTS `als_instock_auth_by_instock_info` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `instock_info_id` int unsigned NOT NULL COMMENT '制服倉庫資訊ID',
  `added_instock_info_id` int unsigned NOT NULL COMMENT '額外制服倉庫資訊ID',
  `is_show_button1` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否顯示批量領取按鈕',
  `is_show_button2` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否顯示批量繳回按鈕',
  `is_show_button3` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否顯示申請調撥按鈕',
  `is_show_button4` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否顯示報廢按鈕',
  `is_show_button5` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否顯示調回按鈕',
  `is_show_button6` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否顯示購買入庫按鈕',
  `is_show_button7` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否顯示匯出月底庫存統計表按鈕',
  `del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否刪除(0: 否, 1: 是)',
  `creator_id` int unsigned NOT NULL DEFAULT '0' COMMENT '建立者',
  `updator_id` int unsigned DEFAULT NULL COMMENT '更新者',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立時間',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `instock_info_id` (`instock_info_id`) USING BTREE,
  KEY `added_instock_info_id` (`added_instock_info_id`) USING BTREE,
  KEY `instock_info_id_added_instock_info_id` (`instock_info_id`,`added_instock_info_id`) USING BTREE,
  KEY `instock_info_id_added_instock_info_id_del` (`instock_info_id`,`added_instock_info_id`,`del`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='制服額外權限管理(制服倉庫)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
