-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_department_costs_TW1230 結構
DROP TABLE IF EXISTS `als_department_costs_TW1230`;
CREATE TABLE IF NOT EXISTS `als_department_costs_TW1230` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `cost_element_id` int NOT NULL COMMENT '成本要素_代碼',
  `cost_element_name` varchar(10) NOT NULL COMMENT '成本要素_名稱',
  `actual_costs` int NOT NULL COMMENT '實際成本',
  `opportunity_cost` int NOT NULL DEFAULT '0' COMMENT '計畫成本',
  `factors_accounting` int NOT NULL DEFAULT '0' COMMENT '會計因素',
  `year` int NOT NULL COMMENT '年',
  `season` int NOT NULL COMMENT '季',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '匯入時間',
  `cost_center` varchar(10) NOT NULL DEFAULT 'TW1110' COMMENT '成本中心',
  `merge` int NOT NULL,
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1114 DEFAULT CHARSET=utf8 COMMENT='成本中心_資訊課';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
