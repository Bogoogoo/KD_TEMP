-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_tank_capacity 結構
DROP TABLE IF EXISTS `als_tank_capacity`;
CREATE TABLE IF NOT EXISTS `als_tank_capacity` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號 als_fuel_expense.tank_capacity(20191022)',
  `area` int NOT NULL COMMENT '地區',
  `number_plate` varchar(20) NOT NULL COMMENT '車號',
  `name` int NOT NULL COMMENT '姓名',
  `check_day` int NOT NULL DEFAULT '30' COMMENT '稽核天數',
  `car` varchar(30) NOT NULL COMMENT '車種',
  `capacity` int NOT NULL COMMENT 'cc數',
  `car_year` int NOT NULL COMMENT '車輛年份',
  `travel` int NOT NULL COMMENT '追扣出遊',
  `stop_capacity` decimal(6,2) NOT NULL COMMENT '跳停容量',
  `mileage` int NOT NULL COMMENT '里程數',
  `oil_products` varchar(10) NOT NULL COMMENT '油品',
  `update_data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  `photo_img` varchar(255) DEFAULT NULL COMMENT '行照圖片 ',
  `mileage_img` varchar(255) DEFAULT NULL COMMENT '里程數圖片',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=383 DEFAULT CHARSET=utf8 COMMENT='油箱容量';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
