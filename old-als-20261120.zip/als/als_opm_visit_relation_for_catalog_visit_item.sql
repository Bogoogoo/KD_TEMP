-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_visit_relation_for_catalog_visit_item 結構
DROP TABLE IF EXISTS `als_opm_visit_relation_for_catalog_visit_item`;
CREATE TABLE IF NOT EXISTS `als_opm_visit_relation_for_catalog_visit_item` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `als_opm_visit_id` int NOT NULL COMMENT '參訪紀錄ID',
  `als_catalog_for_visit_item_id` int NOT NULL COMMENT '參觀品項ID',
  `creator` int NOT NULL COMMENT '建立者ID',
  `updator` int DEFAULT NULL COMMENT '更新者ID',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否刪除(0=否, 1=是)',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立時間',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `als_opm_visit_id` (`als_opm_visit_id`) USING BTREE,
  KEY `als_catalog_for_visit_item_id` (`als_catalog_for_visit_item_id`) USING BTREE,
  KEY `creator` (`creator`) USING BTREE,
  KEY `updator` (`updator`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=61304 DEFAULT CHARSET=utf8 COMMENT='參訪紀錄與參觀品項關聯資料';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
