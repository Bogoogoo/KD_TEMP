-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_monthly_sales_detail_2 結構
DROP TABLE IF EXISTS `als_monthly_sales_detail_2`;
CREATE TABLE IF NOT EXISTS `als_monthly_sales_detail_2` (
  `id` int NOT NULL AUTO_INCREMENT,
  `department_exp` varchar(10) NOT NULL COMMENT '部門',
  `b_group` varchar(10) NOT NULL COMMENT '大群組說明',
  `l_group` varchar(10) NOT NULL COMMENT '小群組',
  `f_name` varchar(10) NOT NULL COMMENT '姓',
  `l_name` varchar(10) NOT NULL COMMENT '名',
  `customer_id` varchar(10) NOT NULL COMMENT '買方',
  `customer_name` varchar(50) NOT NULL COMMENT '買方說明',
  `search_parameter` varchar(20) NOT NULL COMMENT '搜尋條件1',
  `industry` varchar(5) NOT NULL COMMENT '行業別',
  `consignor` varchar(30) NOT NULL,
  `date` date DEFAULT NULL COMMENT '預計發貨日期',
  `materials_id` varchar(20) NOT NULL COMMENT '物料',
  `batch` varchar(10) NOT NULL COMMENT '批次',
  `materials_name` varchar(50) NOT NULL COMMENT '物料說明',
  `trading_volume` float NOT NULL COMMENT '交貨數量',
  `unit_price` float NOT NULL COMMENT '單價本位幣',
  `no_tax_price` int NOT NULL COMMENT '未稅本位幣',
  `tax_price` int NOT NULL COMMENT '稅額本位幣',
  `price` int NOT NULL COMMENT '金額本位幣',
  `address` varchar(100) NOT NULL COMMENT '送貨地址',
  `address3` varchar(100) NOT NULL COMMENT '送貨地址3',
  `requirement` text NOT NULL COMMENT '貨品需求',
  `deduction_project` varchar(100) NOT NULL COMMENT '扣瑕/專案',
  `to_warehouse` varchar(100) NOT NULL COMMENT 'TO 倉管',
  `sell_delivery_id` varchar(20) NOT NULL COMMENT '銷項交貨單號',
  `payment_memo` varchar(100) NOT NULL COMMENT '請款單客戶備註',
  `payment_id` varchar(20) NOT NULL COMMENT '請款單號',
  `create_date` date DEFAULT NULL COMMENT '建立日期',
  `sell_doc_id` varchar(50) NOT NULL COMMENT '銷售文件號碼',
  `area_id` varchar(20) NOT NULL COMMENT '區域',
  `receipt` varchar(20) NOT NULL COMMENT '發票號碼',
  `delivery_date` date DEFAULT NULL COMMENT '交貨日期',
  `customer_group` varchar(20) NOT NULL COMMENT '客戶群組一說明',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '匯入時間',
  `del` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=429578 DEFAULT CHARSET=utf8 COMMENT='歷年銷售明細';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
