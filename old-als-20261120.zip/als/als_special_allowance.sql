-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_special_allowance 結構
DROP TABLE IF EXISTS `als_special_allowance`;
CREATE TABLE IF NOT EXISTS `als_special_allowance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '姓名',
  `employee_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '員工編號',
  `mail` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '信箱',
  `fraction_1A` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_1B` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_1C` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_2A` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_2B` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_2C` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_3A` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_3B` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_3C` float(6,2) DEFAULT NULL COMMENT '分數',
  `fraction_sum` float(6,2) DEFAULT NULL COMMENT '分數合計',
  `score_1A` int DEFAULT NULL COMMENT '評分',
  `score_1B` int DEFAULT NULL COMMENT '評分',
  `score_1C` int DEFAULT NULL COMMENT '評分',
  `score_2A` int DEFAULT NULL COMMENT '評分',
  `score_2B` int DEFAULT NULL COMMENT '評分',
  `score_2C` int DEFAULT NULL COMMENT '評分',
  `score_3A` int DEFAULT NULL COMMENT '評分',
  `score_3B` int DEFAULT NULL COMMENT '評分',
  `score_3C` int DEFAULT NULL COMMENT '評分',
  `score_sum` int DEFAULT NULL COMMENT '評分合計',
  `month` tinyint DEFAULT NULL COMMENT '寄送要顯示得月份',
  `tax` int DEFAULT NULL COMMENT '稅款',
  `transfer` int DEFAULT NULL COMMENT '匯款金額',
  `del` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9259 DEFAULT CHARSET=utf8 COMMENT='特殊津貼(20210727)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
