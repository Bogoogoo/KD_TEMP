-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_fuel_receipt 結構
DROP TABLE IF EXISTS `als_fuel_receipt`;
CREATE TABLE IF NOT EXISTS `als_fuel_receipt` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `fuel_expense_id` int NOT NULL COMMENT '油費登錄id',
  `money` int NOT NULL COMMENT '金額',
  `money_no_tax` int NOT NULL,
  `money_tax` int NOT NULL,
  `stop_capacity` decimal(6,2) NOT NULL COMMENT '跳停容量',
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '數量',
  `subsidy` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '補貼%數',
  `n_money` int NOT NULL DEFAULT '0' COMMENT '金額_扣除未達標準',
  `inconsistent` int NOT NULL DEFAULT '1' COMMENT '不符情況',
  `total_money` int NOT NULL DEFAULT '0' COMMENT '最後計算金額',
  `fuel_date` date DEFAULT NULL COMMENT '日期',
  `check_personnel` int NOT NULL DEFAULT '0' COMMENT '稽核人員',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16308 DEFAULT CHARSET=utf8 COMMENT='加油單據';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
