-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_visit_cn 結構
DROP TABLE IF EXISTS `als_opm_visit_cn`;
CREATE TABLE IF NOT EXISTS `als_opm_visit_cn` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(45) NOT NULL COMMENT '客戶代號',
  `visit_date` date NOT NULL COMMENT '拜訪日期',
  `visit_place` varchar(45) NOT NULL COMMENT '拜訪地點',
  `visit_t1` varchar(8) NOT NULL COMMENT '展示館',
  `visit_t2` varchar(8) NOT NULL COMMENT '倉庫',
  `visit_t4` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'K大視訊',
  `company_name` varchar(100) NOT NULL COMMENT '公司名稱',
  `company_phone1` varchar(10) NOT NULL COMMENT '公司電話區碼',
  `company_phone2` varchar(20) NOT NULL COMMENT '公司電話',
  `company_address` varchar(100) NOT NULL COMMENT '公司地址',
  `is_finish_check` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '是否完成普查',
  `area` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '區域 als_sales_area_level4.id (20200206)',
  `invite_area` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '邀約區域',
  `customer_name` varchar(50) NOT NULL COMMENT '客戶名稱',
  `cell_phone` varchar(50) NOT NULL COMMENT '行動電話',
  `inviter` varchar(20) NOT NULL COMMENT '邀請者',
  `receptionist` varchar(20) NOT NULL COMMENT '接待者',
  `time1` time(2) NOT NULL COMMENT '開始接待時間',
  `time2` time NOT NULL COMMENT '結束接待時間',
  `amount` int NOT NULL COMMENT '參訪人數',
  `t1` varchar(8) NOT NULL COMMENT '設計師',
  `t2` varchar(8) NOT NULL COMMENT '木工',
  `t3` varchar(8) NOT NULL COMMENT '業主',
  `t4` varchar(20) NOT NULL COMMENT '其他',
  `executor` varchar(20) NOT NULL COMMENT '交辦執行者',
  `t2_1` varchar(8) NOT NULL COMMENT '木地板',
  `t2_2` varchar(8) NOT NULL COMMENT '木皮版',
  `t2_3` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '文創小品',
  `t2_4` varchar(8) NOT NULL COMMENT '柜体板',
  `t2_5` varchar(8) NOT NULL COMMENT 'PP板',
  `note` text NOT NULL COMMENT '接待內容',
  `project_name` varchar(100) NOT NULL COMMENT '項目名稱',
  `constructor` varchar(100) NOT NULL COMMENT '設計/施工方',
  `duration` varchar(50) NOT NULL COMMENT '工期',
  `site` varchar(50) NOT NULL COMMENT '工地',
  `reservation` varchar(8) NOT NULL COMMENT '預約',
  `special` varchar(8) NOT NULL COMMENT '特約',
  `g1` varchar(8) NOT NULL COMMENT '卷尺',
  `g2` varchar(8) NOT NULL COMMENT '筆記本',
  `g3` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'K6天然實體型錄',
  `g4` varchar(8) NOT NULL COMMENT 'K3實體型錄',
  `g5` varchar(8) NOT NULL COMMENT '木地板印刷型錄',
  `g6` varchar(8) NOT NULL COMMENT '來店禮',
  `g7` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'K6科技實體型錄',
  `g8` varchar(8) NOT NULL COMMENT 'K6實體型錄',
  `g9` varchar(8) NOT NULL COMMENT 'K5實體型錄',
  `g10` varchar(8) NOT NULL COMMENT 'PP型錄',
  `gift_num` int NOT NULL COMMENT '贈送數量',
  `recorder` int DEFAULT NULL,
  `del_id` int DEFAULT NULL,
  `del` int NOT NULL DEFAULT '0',
  `updater` int NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `h1` varchar(8) DEFAULT NULL COMMENT '停車欄位用',
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `del` (`del`),
  KEY `customer_id_del` (`customer_id`,`del`)
) ENGINE=InnoDB AUTO_INCREMENT=42365 DEFAULT CHARSET=utf8 COMMENT='參訪紀錄_大陸(20200204)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
