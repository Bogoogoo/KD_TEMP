-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_fuel_aid_area 結構
DROP TABLE IF EXISTS `als_fuel_aid_area`;
CREATE TABLE IF NOT EXISTS `als_fuel_aid_area` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `distance` varchar(10) NOT NULL COMMENT '距離',
  `fuel_aid` varchar(15) NOT NULL COMMENT '油量輔助',
  `area` varchar(10) NOT NULL COMMENT '區域',
  `average_oil` decimal(6,3) NOT NULL COMMENT '平均油價',
  `subsidy_1` decimal(4,2) NOT NULL COMMENT '補貼_1',
  `subsidy_2` decimal(4,2) NOT NULL COMMENT '補貼_2',
  `subsidy_money` decimal(6,4) NOT NULL COMMENT '平均油價x補貼_1x補貼_2',
  `not_usual` int NOT NULL COMMENT '非一般區域',
  `sort` int NOT NULL COMMENT '排序',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COMMENT='油資補貼區域';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
