-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_catalog_reason_for_release 結構
DROP TABLE IF EXISTS `als_catalog_reason_for_release`;
CREATE TABLE IF NOT EXISTS `als_catalog_reason_for_release` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '型錄ID',
  `reason` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '發放原因',
  `type` tinyint(1) unsigned zerofill NOT NULL DEFAULT '1' COMMENT '發放原因類型：非規定之客戶(0), 規定之客戶(1)',
  `visible` tinyint(1) unsigned zerofill NOT NULL DEFAULT '1' COMMENT '是否顯示',
  `del` tinyint(1) unsigned zerofill NOT NULL DEFAULT '0' COMMENT '是否刪除',
  `creator` int NOT NULL COMMENT '建立者',
  `updater` int DEFAULT NULL COMMENT '更新者',
  `creation_datetime` timestamp NOT NULL COMMENT '建立時間',
  `modify_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '變更時間',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `creator` (`creator`) USING BTREE,
  KEY `updater` (`updater`) USING BTREE,
  KEY `del` (`del`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `reason` (`reason`) USING BTREE,
  KEY `visible` (`visible`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='展示館型錄發放原因管理';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
