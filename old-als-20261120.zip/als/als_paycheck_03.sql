-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_paycheck_03 結構
DROP TABLE IF EXISTS `als_paycheck_03`;
CREATE TABLE IF NOT EXISTS `als_paycheck_03` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `del` int NOT NULL DEFAULT '0',
  `category` varchar(2) NOT NULL DEFAULT '03' COMMENT '帳套',
  `paycheck_mail` text COMMENT '信箱',
  `department` varchar(10) DEFAULT NULL COMMENT '單位',
  `job` varchar(10) DEFAULT NULL COMMENT '職稱',
  `country` varchar(10) DEFAULT NULL COMMENT '國籍',
  `employee_code` varchar(10) DEFAULT NULL COMMENT '員工代號',
  `name` varchar(10) DEFAULT NULL COMMENT '員工姓名',
  `memo` text,
  `send_status` int DEFAULT '0' COMMENT '發送狀態',
  `year` varchar(4) NOT NULL,
  `month` varchar(2) NOT NULL,
  `B1` int NOT NULL DEFAULT '0',
  `B2` int NOT NULL DEFAULT '0',
  `A1` int NOT NULL DEFAULT '0',
  `A2` int NOT NULL DEFAULT '0',
  `A3` int NOT NULL DEFAULT '0',
  `A4` int NOT NULL DEFAULT '0',
  `A5` int NOT NULL DEFAULT '0',
  `A6` int NOT NULL DEFAULT '0',
  `A7` int NOT NULL DEFAULT '0',
  `A8` int NOT NULL DEFAULT '0',
  `A9` int NOT NULL DEFAULT '0',
  `A10` int NOT NULL DEFAULT '0',
  `A11` int NOT NULL DEFAULT '0',
  `A12` int NOT NULL DEFAULT '0',
  `A13` int NOT NULL DEFAULT '0',
  `A14` int NOT NULL DEFAULT '0',
  `A15` int NOT NULL DEFAULT '0',
  `A16` int NOT NULL DEFAULT '0',
  `A17` int NOT NULL DEFAULT '0',
  `A18` int NOT NULL DEFAULT '0',
  `A19` int NOT NULL DEFAULT '0',
  `A20` int NOT NULL DEFAULT '0',
  `A21` int NOT NULL DEFAULT '0',
  `A22` int NOT NULL DEFAULT '0',
  `A23` int NOT NULL DEFAULT '0',
  `A24` int NOT NULL DEFAULT '0',
  `A25` int NOT NULL DEFAULT '0',
  `A26` int NOT NULL DEFAULT '0',
  `A27` int NOT NULL DEFAULT '0',
  `A28` int NOT NULL DEFAULT '0',
  `A29` int NOT NULL DEFAULT '0',
  `A30` int NOT NULL DEFAULT '0',
  `A31` int NOT NULL DEFAULT '0',
  `A32` int NOT NULL DEFAULT '0',
  `A33` int NOT NULL DEFAULT '0',
  `A34` int NOT NULL DEFAULT '0',
  `A35` int NOT NULL DEFAULT '0',
  `A36` int NOT NULL DEFAULT '0',
  `A37` int NOT NULL DEFAULT '0',
  `A38` int NOT NULL DEFAULT '0',
  `A39` int NOT NULL DEFAULT '0',
  `A40` int NOT NULL DEFAULT '0',
  `A41` int NOT NULL DEFAULT '0',
  `A42` int NOT NULL DEFAULT '0',
  `A43` int NOT NULL DEFAULT '0',
  `A44` int NOT NULL DEFAULT '0',
  `A45` int NOT NULL DEFAULT '0',
  `A46` int NOT NULL DEFAULT '0',
  `A47` int NOT NULL DEFAULT '0',
  `A48` int NOT NULL DEFAULT '0',
  `A49` int NOT NULL DEFAULT '0',
  `A50` int NOT NULL DEFAULT '0',
  `A51` int NOT NULL DEFAULT '0',
  `A52` int NOT NULL DEFAULT '0',
  `A53` double NOT NULL DEFAULT '0',
  `A54` double NOT NULL DEFAULT '0',
  `A55` double NOT NULL DEFAULT '0',
  `A56` double NOT NULL DEFAULT '0',
  `A57` double NOT NULL DEFAULT '0',
  `A58` double NOT NULL DEFAULT '0',
  `A59` double NOT NULL DEFAULT '0',
  `A60` double NOT NULL DEFAULT '0',
  `A61` double NOT NULL DEFAULT '0',
  `A62` double NOT NULL DEFAULT '0',
  `A63` double NOT NULL DEFAULT '0',
  `A64` double NOT NULL DEFAULT '0',
  `A65` double NOT NULL DEFAULT '0',
  `A66` double NOT NULL DEFAULT '0',
  `A67` double NOT NULL DEFAULT '0',
  `A68` double NOT NULL DEFAULT '0',
  `A69` double NOT NULL DEFAULT '0',
  `A70` double NOT NULL DEFAULT '0',
  `A71` double NOT NULL DEFAULT '0',
  `A72` double NOT NULL DEFAULT '0',
  `A73` double NOT NULL DEFAULT '0',
  `A74` double NOT NULL DEFAULT '0',
  `A75` double NOT NULL DEFAULT '0',
  `A76` double NOT NULL DEFAULT '0',
  `A77` int NOT NULL DEFAULT '0',
  `A78` int NOT NULL DEFAULT '0',
  `A79` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4258 DEFAULT CHARSET=utf8 COMMENT='薪資單';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
