-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  程序 als.add_partition 結構
DROP PROCEDURE IF EXISTS `add_partition`;
DELIMITER //
CREATE PROCEDURE `add_partition`(
	IN `in_tableName` TEXT,
	IN `in_year` YEAR,
	IN `in_option` TEXT
)
    COMMENT '新增 partition'
BEGIN
	# 迴圈開始 index
	DECLARE _index INT DEFAULT 0;
	DECLARE _date DATE;
	DECLARE _maxDate DATE;
	DECLARE _maxYear YEAR;
	DECLARE _partitionKey TEXT DEFAULT '';
	DECLARE _script TEXT DEFAULT '';
	DECLARE _status TEXT DEFAULT 'add';

	SET _date = DATE(CONCAT(in_year, '-01-01'));
	
	IF in_option = 'year' THEN
		SET _maxDate = DATE_ADD(_date, INTERVAL 1 YEAR);
		SET _maxYear = YEAR(_maxDate);
	
		SET _partitionKey = CONCAT('y', DATE_FORMAT(_date, '%Y'));
		SELECT IF(COUNT(*), 'exist', 'add') INTO _status FROM `information_schema`.`partitions` 
		WHERE 
			`partition_name` = _partitionKey COLLATE utf8_general_ci AND 
			`TABLE_NAME` = in_tableName COLLATE utf8_general_ci;		
		
		/*SET @_script = CONCAT(
			'ALTER TABLE `', 
			in_tableName,
			'` ADD PARTITION (PARTITION ',
			_partitionKey, 
			' VALUES LESS THAN (',
			_maxYear,
			') ENGINE = InnoDB)'
		);*/
		
		SET @_script = CONCAT(
			'ALTER TABLE `',
			in_tableName,
			'` REORGANIZE PARTITION ymax INTO (PARTITION ',
			_partitionKey, 
			' VALUES LESS THAN (',						
			_maxYear,
			'), PARTITION ymax VALUES LESS THAN MAXVALUE)'
		);
		
		IF _status = 'add' THEN
			PREPARE stmt FROM @_script;
			EXECUTE stmt;
		END IF;
		
		INSERT INTO `partition_history`(
			`inputTableName`, 
			`inputYear`, 
			`partitionKey`, 
			`maxDate`,
			`script`,
			`status`
		) VALUES (
			in_tableName, 
			in_year, 
			_partitionKey,
			_maxDate,
			@_script,
			_status
		);
	ELSEIF in_option = 'month' THEN
		SET _maxDate = DATE_ADD(_date, INTERVAL 1 MONTH);
		WHILE _index < 12 DO
			SET _partitionKey = CONCAT('y', DATE_FORMAT(_date, '%Y_%m'));
		
			SELECT IF(COUNT(*), 'exist', 'add') INTO _status FROM `information_schema`.`partitions` 
			WHERE 
				`partition_name` = _partitionKey COLLATE utf8_general_ci AND 
				`TABLE_NAME` = in_tableName COLLATE utf8_general_ci;
		
			/*SET @_script = CONCAT(
				'ALTER TABLE `', 
				in_tableName,
				'` ADD PARTITION (PARTITION ',
				_partitionKey, 
				' VALUES LESS THAN ("',
				_maxDate,
				'") ENGINE = InnoDB)'
			);*/
			
			SET @_script = CONCAT(
				'ALTER TABLE `',
				in_tableName,
				'` REORGANIZE PARTITION ymax INTO (PARTITION ',
				_partitionKey, 
				' VALUES LESS THAN ("',						
				_maxDate,
				'"), PARTITION ymax VALUES LESS THAN MAXVALUE)'
			);
		
			IF _status = 'add' THEN
				PREPARE stmt FROM @_script;
				EXECUTE stmt;
			END IF;
		
			INSERT INTO `partition_history`(
				`inputTableName`, 
				`inputYear`, 
				`partitionKey`, 
				`maxDate`,
				`script`,
				`status`
			) VALUES (
				in_tableName, 
				in_year, 
				_partitionKey,
				_maxDate,
				@_script,
				_status
			);
		
			SET _date = DATE_ADD(_date, INTERVAL 1 MONTH);
			SET _maxDate = DATE_ADD(_date, INTERVAL 1 MONTH);		
			SET _index = _index + 1;
		END WHILE;
	END IF;
	
END//
DELIMITER ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
