-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_receive 結構
DROP TABLE IF EXISTS `als_receive`;
CREATE TABLE IF NOT EXISTS `als_receive` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `uniforms_list_id` int NOT NULL COMMENT '制服種類',
  `recipients` varchar(15) NOT NULL COMMENT '領取人',
  `amount` int NOT NULL COMMENT '數量',
  `receive_date` date NOT NULL COMMENT '領取日期',
  `applicant` int NOT NULL COMMENT '申請人',
  `warehouse` int NOT NULL COMMENT '領取倉庫',
  `return_status` int NOT NULL DEFAULT '0' COMMENT '歸還狀態',
  `return_quantity` int NOT NULL DEFAULT '0' COMMENT '歸還數量',
  `cancel` int NOT NULL DEFAULT '0' COMMENT '是否取消',
  `cancel_people` int NOT NULL DEFAULT '0' COMMENT '取消人',
  `memo` varchar(20) DEFAULT NULL COMMENT '備註',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `del` tinyint(1) DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  KEY `uniforms_list_id` (`uniforms_list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44127 DEFAULT CHARSET=utf8 COMMENT='領取紀錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
