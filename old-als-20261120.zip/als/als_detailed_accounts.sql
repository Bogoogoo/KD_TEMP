-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_detailed_accounts 結構
DROP TABLE IF EXISTS `als_detailed_accounts`;
CREATE TABLE IF NOT EXISTS `als_detailed_accounts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `gl` int NOT NULL COMMENT 'G/L科目',
  `posting_date` date NOT NULL COMMENT '過帳日期',
  `file_number` bigint NOT NULL COMMENT '文件號碼',
  `file_date` date NOT NULL COMMENT '文件日期',
  `article` varchar(100) DEFAULT NULL COMMENT '內文',
  `national_currency` int NOT NULL COMMENT '本國貨幣計算之金額',
  `settlement_documents` varchar(11) DEFAULT NULL COMMENT '結清文件',
  `reversal_sort` varchar(11) DEFAULT NULL COMMENT '沖銷科目類型',
  `reversal_number` varchar(11) DEFAULT NULL COMMENT '沖銷科目號碼',
  `cost` varchar(10) NOT NULL COMMENT '成本中心',
  `turn` varchar(11) DEFAULT NULL COMMENT '迴轉',
  `opportunity_cost` int NOT NULL DEFAULT '0' COMMENT '計畫成本',
  `year` int NOT NULL COMMENT '年',
  `season` int NOT NULL COMMENT '季',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '匯入時間',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=724543 DEFAULT CHARSET=utf8 COMMENT='部門費用查詢明細(20191224)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
