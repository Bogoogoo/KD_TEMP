-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_report_list_sales 結構
DROP TABLE IF EXISTS `als_daily_report_list_sales`;
CREATE TABLE IF NOT EXISTS `als_daily_report_list_sales` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `work_list_id` int NOT NULL COMMENT '業務日報編號(20191113)',
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '從CRM匯入日期',
  `CRM_branch` int NOT NULL COMMENT '業務人員所在大區',
  `CRM_area` int DEFAULT NULL COMMENT '業務人員所在小區',
  `list_mark` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '主管備註內容',
  `RecordDate` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '日期(CRM日期))',
  `SalesName` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '業務人員姓名',
  `CompanyTypeID` varchar(15) DEFAULT NULL COMMENT '公司型態',
  `CompanyFullName` mediumtext COMMENT '公司全名',
  `CompanyName` mediumtext COMMENT '公司名稱',
  `ContactID` varchar(20) DEFAULT NULL COMMENT '聯絡人代號',
  `ContactName` varchar(60) DEFAULT NULL COMMENT '聯絡人姓名',
  `SalesWorkTypeName` varchar(30) DEFAULT NULL COMMENT '工作類別名稱',
  `WorkProperty` varchar(10) DEFAULT NULL COMMENT '資料型態',
  `LeadName` mediumtext COMMENT '項目',
  `WorkHours` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拜訪時間區間(時分-時分)',
  `WorkHours_1` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '拜訪開始時間(時分秒)',
  `WorkHours_2` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '拜訪結束時間(時分秒)',
  `WorkHours_3` int DEFAULT '0' COMMENT '工作分鐘(20191113)',
  `VisitArea` mediumtext COMMENT '拜訪區域',
  `WorkDescription` longtext COMMENT '最近工作內容',
  `Catalog_Pre` int DEFAULT NULL COMMENT '塗裝板型錄(舊版不分冊) (20191216)',
  `Catalog_Pre_tw` int DEFAULT NULL COMMENT '木地板型錄',
  `Catalog_Unfin` int DEFAULT NULL COMMENT '未塗裝型錄',
  `Catalog_Print_Flor` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '木地板/木門印刷型錄(H 20220812)',
  `Catalog_Sample` int DEFAULT NULL COMMENT '啞光型錄(2021/1/28)',
  `Designer_Sample` int DEFAULT NULL COMMENT '設計師盒',
  `DM` int DEFAULT NULL,
  `DVD` int DEFAULT NULL COMMENT '塗裝版型錄(人造木系列) (20191216)',
  `del` tinyint(1) NOT NULL DEFAULT '0',
  `TrackingRecordID` int DEFAULT NULL COMMENT 'CRM唯一值',
  `Catalog_Pre_tw_1` int DEFAULT '0' COMMENT '塗裝版型錄(天然木系列) (20191216)',
  `Catalog_Print_Veneer` int DEFAULT '0' COMMENT '寬幅木地板型錄 (20211119)',
  `Catalog_Print_Door` int DEFAULT '0' COMMENT '塗裝板型錄(新版16格) (20211119)',
  `VisitTime` tinyint(1) NOT NULL DEFAULT '0' COMMENT '拜訪時段',
  `VisitTimeName` varchar(100) DEFAULT NULL COMMENT '拜訪時段文字顯示',
  `ProductLineID` varchar(100) DEFAULT NULL COMMENT '產品線(20230210)',
  `Quantity` float DEFAULT NULL COMMENT '數量(20230210)',
  PRIMARY KEY (`id`),
  KEY `work_list_id` (`work_list_id`),
  KEY `RecordDate` (`RecordDate`),
  KEY `TrackingRecordID` (`TrackingRecordID`),
  KEY `ContactID` (`ContactID`),
  KEY `SalesWorkTypeName` (`SalesWorkTypeName`),
  KEY `del` (`del`),
  KEY `RecordDate_ContactID_SalesWorkTypeName_del` (`RecordDate`,`ContactID`,`SalesWorkTypeName`,`del`)
) ENGINE=InnoDB AUTO_INCREMENT=3930881 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='業務日報明細';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
