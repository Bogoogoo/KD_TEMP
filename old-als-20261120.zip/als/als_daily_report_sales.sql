-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_report_sales 結構
DROP TABLE IF EXISTS `als_daily_report_sales`;
CREATE TABLE IF NOT EXISTS `als_daily_report_sales` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` int NOT NULL COMMENT '姓名',
  `department` int NOT NULL COMMENT '部門',
  `position` int NOT NULL COMMENT '職稱',
  `country` int NOT NULL COMMENT '國家',
  `CRM_branch` int NOT NULL,
  `CRM_area` int DEFAULT NULL,
  `creation_date` date NOT NULL COMMENT '建立時間',
  `creation_date_2` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mark_time` datetime DEFAULT NULL COMMENT '批閱時間',
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最後修改時間',
  `tomorrow_results` text,
  `mark` tinyint(1) NOT NULL DEFAULT '0' COMMENT '批示 (0:沒輸入批是內容 1:批是有撰寫內容)',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '狀態',
  `del` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `name_creation_date` (`name`,`creation_date`),
  KEY `del` (`del`),
  KEY `position_CRM_branch` (`position`,`CRM_branch`)
) ENGINE=InnoDB AUTO_INCREMENT=213338 DEFAULT CHARSET=utf8 COMMENT='業務日報主表(20200110)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
