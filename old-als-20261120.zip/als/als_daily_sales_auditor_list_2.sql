-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_sales_auditor_list_2 結構
DROP TABLE IF EXISTS `als_daily_sales_auditor_list_2`;
CREATE TABLE IF NOT EXISTS `als_daily_sales_auditor_list_2` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `auditor_id` int NOT NULL,
  `report_list_id` int NOT NULL COMMENT 'als_daily_report_list_sales.id(20191001)',
  `report_date` date NOT NULL COMMENT '實際拜訪日期',
  `sales_id` int NOT NULL COMMENT '業務人員',
  `title` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '職稱',
  `phone_1` varchar(100) DEFAULT NULL COMMENT '電話',
  `phone_2` varchar(100) DEFAULT NULL,
  `auditor_date` date DEFAULT NULL COMMENT '稽核日',
  `auditor_phone_call` varchar(20) DEFAULT NULL COMMENT '稽核時打的電話號碼',
  `auditor_name` int DEFAULT NULL,
  `auditor_content` text COMMENT '稽核內容',
  `fraction` varchar(5) DEFAULT '10' COMMENT '分數',
  `response` text COMMENT '主管回覆',
  `punish` int DEFAULT NULL COMMENT '懲處',
  `auditor_status` int NOT NULL DEFAULT '0',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `del` tinyint(1) NOT NULL DEFAULT '0',
  `is_visit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '有無拜訪',
  `is_compare_test` tinyint(1) NOT NULL DEFAULT '0' COMMENT '有無做比較實驗',
  `is_3d` tinyint(1) NOT NULL DEFAULT '0' COMMENT '知道/不知道3D',
  `is_invite` tinyint(1) NOT NULL DEFAULT '0' COMMENT '知道/不知道邀約',
  `auditor_item_set` text COMMENT '稽核項目設定',
  PRIMARY KEY (`id`),
  KEY `report_list_id` (`report_list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54989 DEFAULT CHARSET=utf8 COMMENT='客服稽核新增內明細';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
