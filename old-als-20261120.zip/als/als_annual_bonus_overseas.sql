-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_annual_bonus_overseas 結構
DROP TABLE IF EXISTS `als_annual_bonus_overseas`;
CREATE TABLE IF NOT EXISTS `als_annual_bonus_overseas` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `del` tinyint(1) DEFAULT '0',
  `employee_code` varchar(10) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `mail` text,
  `job` varchar(10) DEFAULT NULL,
  `country` varchar(10) DEFAULT NULL,
  `year` int DEFAULT NULL,
  `annual_bonus` int DEFAULT NULL COMMENT '年終獎金',
  `annual_bonus_deduction` decimal(9,2) DEFAULT NULL COMMENT '年終扣繳',
  `annual_bonus_total` decimal(12,2) NOT NULL,
  `performance` int DEFAULT NULL COMMENT '績效獎金',
  `performance_reward` int DEFAULT NULL COMMENT '績效加減',
  `performance_withdraw` int DEFAULT NULL COMMENT '實領績效',
  `performance_deduction` decimal(9,2) DEFAULT NULL COMMENT '績效扣繳',
  `performance_total` decimal(9,2) DEFAULT NULL COMMENT '實匯績效',
  `NHI` int DEFAULT NULL COMMENT '二代健保',
  `withholding` int DEFAULT NULL COMMENT '代扣1/3薪',
  `withholding_1` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=utf8 COMMENT='年終績效獎金_海外';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
