-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_daily_report 結構
DROP TABLE IF EXISTS `als_daily_report`;
CREATE TABLE IF NOT EXISTS `als_daily_report` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` int NOT NULL COMMENT '姓名',
  `department` int NOT NULL COMMENT '部門',
  `position` int NOT NULL COMMENT '職稱',
  `country` int NOT NULL COMMENT '國家',
  `creation_date` date NOT NULL COMMENT '日報時間',
  `creation_date_2` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '日報建立時間',
  `out_time` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '公出時間',
  `mark_time` datetime DEFAULT NULL COMMENT '批閱時間',
  `work_matters` text,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最後修改時間',
  `today_results` text NOT NULL COMMENT '本日成果',
  `tomorrow_results` text NOT NULL COMMENT '明日計劃',
  `reflect_suggest` text NOT NULL COMMENT '反應建議',
  `mark` int NOT NULL DEFAULT '0' COMMENT '批示',
  `status` int NOT NULL DEFAULT '0' COMMENT '狀態',
  `del` tinyint(1) NOT NULL DEFAULT '0',
  `today_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '今日上傳狀態',
  `text_count` int DEFAULT '0' COMMENT '文字數量',
  PRIMARY KEY (`id`),
  KEY `creation_date` (`creation_date`),
  KEY `name` (`name`),
  KEY `name_del` (`name`,`del`),
  KEY `department` (`department`),
  KEY `position` (`position`),
  KEY `country` (`country`),
  KEY `mark` (`mark`),
  KEY `status` (`status`),
  KEY `today_status` (`today_status`)
) ENGINE=InnoDB AUTO_INCREMENT=310555 DEFAULT CHARSET=utf8 COMMENT='每日報表主表(20200110)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
