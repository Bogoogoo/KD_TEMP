-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_annual_project 結構
DROP TABLE IF EXISTS `als_annual_project`;
CREATE TABLE IF NOT EXISTS `als_annual_project` (
  `customer_id` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客戶編號',
  `term` varchar(50) NOT NULL COMMENT '回饋書已簽回 (簽約期限)',
  `rate` varchar(50) NOT NULL COMMENT '級距',
  `money` int NOT NULL COMMENT '年度回饋 目前實際達成金額',
  `target1` int NOT NULL COMMENT '已簽約目標金額',
  `target2` int NOT NULL COMMENT '已簽約超標金額',
  `target1_reach` int NOT NULL,
  `target2_reach` int NOT NULL,
  `bonus` int NOT NULL,
  `bonus_use` int NOT NULL,
  `bonus_last` int NOT NULL,
  `bonus_name` text NOT NULL,
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '匯入時間',
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
