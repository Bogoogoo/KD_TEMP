-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_message_mail 結構
DROP TABLE IF EXISTS `als_message_mail`;
CREATE TABLE IF NOT EXISTS `als_message_mail` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '標題',
  `contents` longtext NOT NULL COMMENT '內容',
  `meg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '日期',
  `to_name` int NOT NULL COMMENT '收信人',
  `from_name` int NOT NULL COMMENT '寄件人',
  `vie` int NOT NULL DEFAULT '0' COMMENT '觀看',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  `is_notice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否月報提醒，1：是，0：否',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=204595 DEFAULT CHARSET=utf8 COMMENT='系統內信件';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
