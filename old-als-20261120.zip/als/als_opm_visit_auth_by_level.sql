-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_visit_auth_by_level 結構
DROP TABLE IF EXISTS `als_opm_visit_auth_by_level`;
CREATE TABLE IF NOT EXISTS `als_opm_visit_auth_by_level` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `opm_visit_info_id` int NOT NULL COMMENT '參訪記錄資訊ID',
  `level_id` int NOT NULL COMMENT '部門ID',
  `is_show_button1` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示新增紀錄按鈕',
  `is_show_button2` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示修改紀錄按鈕',
  `is_show_button3` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示刪除紀錄按鈕',
  `is_show_button4` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示匯出EXCEL按鈕',
  `is_show_button5` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示各區參訪數按鈕',
  `is_show_button6` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示各區參訪數EXCEL按鈕',
  `is_show_button7` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示各地區年度分析按鈕',
  `is_show_button8` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示地區選擇分析按鈕',
  `is_show_button9` tinyint NOT NULL DEFAULT '0' COMMENT '是否顯示展示館型錄發放統計按鈕',
  `del` tinyint NOT NULL DEFAULT '0' COMMENT '是否刪除(0=>否, 1=>是)',
  `creator_id` int NOT NULL DEFAULT '0' COMMENT '建立者ID',
  `updator_id` int DEFAULT NULL COMMENT '更新者ID',
  `created_at` timestamp NULL DEFAULT NULL COMMENT '建立時間',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `opm_visit_info_id` (`opm_visit_info_id`) USING BTREE,
  KEY `level_id` (`level_id`) USING BTREE,
  KEY `opm_visit_info_id_level_id` (`opm_visit_info_id`,`level_id`) USING BTREE,
  KEY `del` (`del`) USING BTREE,
  KEY `opm_visit_info_id_level_id_del` (`opm_visit_info_id`,`level_id`,`del`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='參訪紀錄額外權限管理(ByLevel)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
