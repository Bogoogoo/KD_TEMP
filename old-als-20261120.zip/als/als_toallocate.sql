-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_toallocate 結構
DROP TABLE IF EXISTS `als_toallocate`;
CREATE TABLE IF NOT EXISTS `als_toallocate` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `uniforms_list_id` int NOT NULL COMMENT '制服種類',
  `toallocate` int NOT NULL COMMENT '入庫倉庫',
  `amount` int NOT NULL COMMENT '數量',
  `toallocate_date` date NOT NULL COMMENT '申請調撥日期',
  `applicant` int NOT NULL COMMENT '申請人',
  `warehouse` int NOT NULL COMMENT '調撥倉庫',
  `memo` varchar(15) NOT NULL,
  `status` int NOT NULL DEFAULT '1' COMMENT '調撥狀態',
  `confirm_this_request` varchar(5) NOT NULL DEFAULT '' COMMENT '確認申請人',
  `allocation` varchar(5) NOT NULL DEFAULT '' COMMENT '調撥人',
  `confirm_allocation` varchar(5) NOT NULL DEFAULT '' COMMENT '確認調撥人',
  `confirm_date` date DEFAULT NULL COMMENT '確認日期',
  `entry_date` date DEFAULT NULL COMMENT '日庫日期',
  `del_people` varchar(7) NOT NULL DEFAULT '' COMMENT '刪除人員',
  `import_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `del` int DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6295 DEFAULT CHARSET=utf8 COMMENT='申請調撥';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
