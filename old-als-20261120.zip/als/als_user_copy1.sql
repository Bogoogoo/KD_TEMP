-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_user_copy1 結構
DROP TABLE IF EXISTS `als_user_copy1`;
CREATE TABLE IF NOT EXISTS `als_user_copy1` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `account` varchar(20) NOT NULL COMMENT '帳號',
  `password` varchar(50) NOT NULL COMMENT '密碼',
  `employee_id` varchar(20) DEFAULT NULL COMMENT '工號',
  `name` varchar(20) NOT NULL COMMENT '姓名',
  `level` int NOT NULL COMMENT '身份 als_level(20191122)',
  `position` int NOT NULL COMMENT 'als_position.id(20190927)',
  `als_uniforms_wh` int NOT NULL DEFAULT '0' COMMENT '分公司 als_uniforms_wh.id(20191023)',
  `language` int NOT NULL COMMENT '語言(1繁體 2簡體 3英文) (20191230)',
  `c_oil` int NOT NULL DEFAULT '0' COMMENT '車補審核',
  `cost_center_status` int NOT NULL DEFAULT '0' COMMENT '成本中心狀態',
  `cost_center` varchar(200) NOT NULL DEFAULT ' ' COMMENT '成本中心',
  `opm_status` int NOT NULL DEFAULT '0' COMMENT 'opm權限(0=無,1=看小地區,2=看大地區,3=看所有)',
  `opm` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'opm地區 als_opm_area_b(20191008)',
  `hrtest` varchar(200) NOT NULL DEFAULT '',
  `transfer` int NOT NULL DEFAULT '0' COMMENT '轉接連絡',
  `ga_mail` int NOT NULL DEFAULT '0' COMMENT '郵務業務權限',
  `pasw` date DEFAULT NULL COMMENT '密碼變更日期',
  `leave_date` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '' COMMENT '離職日(20190927)',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  `ad_account` varchar(100) DEFAULT NULL COMMENT '綁定AP網域帳號',
  `sales_level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '業務管理群組',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `account_password` (`account`,`password`)
) ENGINE=InnoDB AUTO_INCREMENT=2465 DEFAULT CHARSET=utf8 COMMENT='後勤員工資料表';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
