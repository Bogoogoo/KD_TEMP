-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_account_receivable 結構
DROP TABLE IF EXISTS `als_account_receivable`;
CREATE TABLE IF NOT EXISTS `als_account_receivable` (
  `id` int NOT NULL AUTO_INCREMENT,
  `small_area` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '小區(20211015)',
  `name` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '業務姓名(20211015)',
  `customer_id` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '客戶編號',
  `customer_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '客戶名稱(20211015 不跟客戶主黨關聯,因為不常更新)',
  `shipment_start_date` date DEFAULT NULL COMMENT '出貨起始日期',
  `shipment_end_date` date DEFAULT NULL COMMENT '出貨結束日期',
  `payment_date` date DEFAULT NULL COMMENT '預計收款時間',
  `description` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '說明',
  `shipment_amount` float(10,0) DEFAULT NULL COMMENT '出貨金額(20211015)',
  `overpayment` float(10,0) DEFAULT NULL COMMENT '多收款金額(20211015)',
  `amount_received` float(10,0) DEFAULT '0' COMMENT '應收款金額',
  `creator_id` int DEFAULT NULL COMMENT '建立者編號',
  `create_at` timestamp NOT NULL COMMENT '建立時間',
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  `del` tinyint(1) DEFAULT '0' COMMENT '刪除標記',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=318 DEFAULT CHARSET=utf8 COMMENT='應收帳款明細(大陸) 20210917';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
