-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_paycheck_cn 結構
DROP TABLE IF EXISTS `als_paycheck_cn`;
CREATE TABLE IF NOT EXISTS `als_paycheck_cn` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `del` int NOT NULL DEFAULT '0',
  `category` varchar(2) NOT NULL DEFAULT 'cn' COMMENT '帳套',
  `paycheck_mail` text COMMENT '信箱',
  `department` varchar(10) DEFAULT NULL COMMENT '單位',
  `job` varchar(10) DEFAULT NULL COMMENT '職稱',
  `cellphone` varchar(15) DEFAULT NULL COMMENT '國籍',
  `employee_code` varchar(10) DEFAULT NULL COMMENT '員工代號',
  `name` varchar(10) DEFAULT NULL COMMENT '員工姓名',
  `memo` text,
  `send_status` int NOT NULL DEFAULT '0' COMMENT '發送狀態',
  `year` varchar(4) NOT NULL,
  `month` varchar(2) NOT NULL,
  `A1` double NOT NULL DEFAULT '0',
  `A2` double NOT NULL DEFAULT '0',
  `A3` double NOT NULL DEFAULT '0',
  `A4` double NOT NULL DEFAULT '0',
  `A5` double NOT NULL DEFAULT '0',
  `A6` double NOT NULL DEFAULT '0',
  `A7` double NOT NULL DEFAULT '0',
  `A8` double NOT NULL DEFAULT '0',
  `A9` double NOT NULL DEFAULT '0',
  `A10` double NOT NULL DEFAULT '0',
  `A11` double NOT NULL DEFAULT '0',
  `A12` double NOT NULL DEFAULT '0',
  `A13` double NOT NULL DEFAULT '0',
  `A14` double NOT NULL DEFAULT '0',
  `A15` double NOT NULL DEFAULT '0',
  `A16` double NOT NULL DEFAULT '0',
  `A17` double NOT NULL DEFAULT '0',
  `A18` double NOT NULL DEFAULT '0',
  `A19` double NOT NULL DEFAULT '0',
  `A20` double NOT NULL DEFAULT '0',
  `A21` double NOT NULL DEFAULT '0',
  `A22` double NOT NULL DEFAULT '0',
  `A23` double NOT NULL DEFAULT '0',
  `A24` double NOT NULL DEFAULT '0',
  `A25` double NOT NULL DEFAULT '0',
  `A26` double NOT NULL DEFAULT '0',
  `A27` double NOT NULL DEFAULT '0',
  `A28` double NOT NULL DEFAULT '0',
  `A29` double NOT NULL DEFAULT '0',
  `A30` text,
  `A31` text,
  `A32` text,
  `A33` text,
  `A34` double NOT NULL DEFAULT '0',
  `A35` double NOT NULL DEFAULT '0',
  `A36` double NOT NULL DEFAULT '0',
  `A37` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4964 DEFAULT CHARSET=utf8 COMMENT='薪資單';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
