-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_car_subsidy_details 結構
DROP TABLE IF EXISTS `als_car_subsidy_details`;
CREATE TABLE IF NOT EXISTS `als_car_subsidy_details` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `name` int NOT NULL COMMENT '姓名',
  `money` int NOT NULL COMMENT '金額',
  `no_tax` int NOT NULL DEFAULT '0',
  `tax` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0' COMMENT '狀態(1:審核中2未通過4審核通過)20191007',
  `apply_date` date DEFAULT NULL,
  `maintenance_date` date DEFAULT NULL,
  `legal_receipt` int NOT NULL DEFAULT '0',
  `legal_receipt_phone` varchar(20) DEFAULT NULL,
  `legal_receipt_address` mediumtext,
  `maintenance_list` int NOT NULL DEFAULT '0',
  `maintenance_list_memo` varchar(50) DEFAULT NULL,
  `vehicle_photo` int NOT NULL DEFAULT '0',
  `vehicle_photo_memo_status` int NOT NULL DEFAULT '0',
  `vehicle_photo_memo` varchar(50) DEFAULT NULL,
  `vehicle_photo_status` int NOT NULL DEFAULT '0',
  `import_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建立時間',
  `del_user` int NOT NULL DEFAULT '0' COMMENT '刪除人員',
  `memo_check1` varchar(50) DEFAULT NULL,
  `check1_user` int NOT NULL DEFAULT '0',
  `check2_user` int NOT NULL DEFAULT '0',
  `memo` varchar(20) DEFAULT NULL COMMENT '備註',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1357 DEFAULT CHARSET=utf8 COMMENT='車輛補助登錄';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
