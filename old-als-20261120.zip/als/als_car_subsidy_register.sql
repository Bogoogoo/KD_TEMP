-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_car_subsidy_register 結構
DROP TABLE IF EXISTS `als_car_subsidy_register`;
CREATE TABLE IF NOT EXISTS `als_car_subsidy_register` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `name` int NOT NULL COMMENT '姓名',
  `car` smallint NOT NULL DEFAULT '0' COMMENT '車種',
  `area_subsidy` int NOT NULL COMMENT '補助區域',
  `area` int NOT NULL DEFAULT '0' COMMENT '區域',
  `car_subsidy` int NOT NULL DEFAULT '0' COMMENT '前期_車補累計金額',
  `period_add_car` int NOT NULL DEFAULT '0' COMMENT '本期新增_車補',
  `period_car_subsidy` int NOT NULL DEFAULT '0' COMMENT '本期發放金額_車補',
  `car_subsidy_next` int unsigned NOT NULL DEFAULT '0' COMMENT '下期車補金額',
  `special_bonus` int NOT NULL DEFAULT '0' COMMENT '前期_特別獎金累計金額',
  `period_add_special` int NOT NULL DEFAULT '0' COMMENT '本期新增_特獎',
  `period_special_bonus` int NOT NULL DEFAULT '0' COMMENT '本期發放金額_特獎',
  `special_bonus_next` int NOT NULL DEFAULT '0' COMMENT '下期_特別獎金',
  `import_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建立時間',
  `del` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8 COMMENT='車輛補助明細';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
