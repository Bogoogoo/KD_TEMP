-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_opm_visit 結構
DROP TABLE IF EXISTS `als_opm_visit`;
CREATE TABLE IF NOT EXISTS `als_opm_visit` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'SAP公司客戶代號',
  `visit_date` date NOT NULL COMMENT '拜訪日期',
  `visit_place` varchar(45) NOT NULL COMMENT '拜訪地點',
  `visit_t1` varchar(8) NOT NULL COMMENT '展示館',
  `visit_t2` varchar(8) NOT NULL COMMENT '倉庫',
  `visit_t3` varchar(8) NOT NULL COMMENT '工廠',
  `visit_t4` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'K大值班',
  `visit_t5` varchar(8) DEFAULT NULL COMMENT 'K大支援',
  `visit_t6` varchar(8) DEFAULT NULL COMMENT '即時通',
  `company_name` varchar(100) NOT NULL COMMENT '公司名稱',
  `company_phone1` varchar(10) NOT NULL COMMENT '電話區碼',
  `company_phone2` varchar(20) NOT NULL COMMENT '公司電話',
  `company_address` varchar(100) NOT NULL COMMENT '公司地址',
  `area` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '追蹤區域',
  `invite_area` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '邀約區域(已棄用)',
  `m_area` varchar(50) NOT NULL COMMENT '月會區域',
  `customer_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '客戶名稱',
  `cell_phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '行動電話',
  `inviter` varchar(20) NOT NULL COMMENT '邀請者',
  `receptionist` varchar(20) NOT NULL COMMENT '接待者',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `time1` time NOT NULL COMMENT '接待時間',
  `time2` time NOT NULL,
  `amount` int NOT NULL COMMENT '參訪人數',
  `t1` varchar(8) NOT NULL COMMENT '設計師',
  `t2` varchar(8) NOT NULL COMMENT '木工',
  `t3` varchar(8) NOT NULL COMMENT '業主',
  `t4` varchar(20) NOT NULL COMMENT '其他',
  `t5` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '建築師',
  `executor` varchar(20) NOT NULL COMMENT '交辦執行者',
  `sales_event_id` int DEFAULT NULL COMMENT '行銷活動ID',
  `t2_1` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '木地板',
  `t2_2` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '木皮版',
  `t2_3` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '木門組',
  `t2_4` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '家具',
  `t2_5` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '其他',
  `t2_6` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '挑板(20191122 add)',
  `t2_7` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '實木餐桌(20200810)',
  `t2_8` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '文創小品(20200810)',
  `t2_9` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '實木家飾(20200810)',
  `t2_10` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '人造櫥櫃板(20210820)',
  `t2_11` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '批批櫥櫃板(20210820)',
  `t2_12` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '定製櫃',
  `note` text NOT NULL COMMENT '接待內容',
  `t3_1` varchar(8) NOT NULL COMMENT '木地板(丈量)',
  `t3_2` varchar(8) NOT NULL COMMENT '木門組(丈量)',
  `measuring_date` date DEFAULT NULL COMMENT '丈量日期',
  `duration` varchar(50) NOT NULL COMMENT '工期',
  `site` varchar(50) NOT NULL COMMENT '工地',
  `reservation` varchar(8) NOT NULL COMMENT '預約',
  `special` varchar(8) NOT NULL COMMENT '特約',
  `recorder` int DEFAULT NULL,
  `company_code` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '無' COMMENT 'CRM公司代碼',
  `crm_contact_person_code` varchar(20) DEFAULT NULL COMMENT 'CRM聯絡人代號',
  `is_finish_check` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '是否客戶資料普查',
  `assigned_item` varchar(200) DEFAULT NULL COMMENT '下交辦事項',
  `has_setting_line_group` varchar(20) DEFAULT NULL COMMENT '是否已建立定製櫃LINE群組',
  `custom_position_id` int DEFAULT NULL COMMENT '客戶職務類別ID',
  `custom_birthday` varchar(10) DEFAULT NULL COMMENT '客戶生日: NULL or X[客戶不用提供] or 月份/日期',
  `custom_line_id` varchar(100) DEFAULT NULL COMMENT '客戶LINE ID',
  `catalog_amount` int DEFAULT NULL COMMENT '型錄需求數量',
  `is_used_camera` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'K大對方是否啟用鏡頭',
  `custom_response` text COMMENT '客戶反饋',
  `custom_assign` text COMMENT '近期指定我司or競品',
  `custom_assign_price` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '案場總金額',
  `custom_assign_amount_of_used` varchar(50) DEFAULT NULL COMMENT '使用數量',
  `capture_photos` json DEFAULT NULL COMMENT 'K大截圖上傳',
  `contact` json DEFAULT NULL COMMENT '客戶資訊',
  `join_contacts` json DEFAULT NULL COMMENT 'K大一同與會客戶',
  `check_status` varchar(50) DEFAULT NULL COMMENT 'K大截圖稽核',
  `check_comment` text COMMENT 'K大截圖異常備註',
  `period_id` int DEFAULT NULL COMMENT 'K大期數ID',
  `is_assigned` varchar(20) DEFAULT NULL COMMENT 'K大是否需下交辦',
  `del_id` int NOT NULL DEFAULT '0',
  `del` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `del` (`del`),
  KEY `customer_id` (`customer_id`),
  KEY `sales_event_id` (`sales_event_id`),
  KEY `company_code` (`company_code`),
  KEY `customer_id_del` (`customer_id`,`del`)
) ENGINE=InnoDB AUTO_INCREMENT=44160 DEFAULT CHARSET=utf8 COMMENT='參訪紀錄_台灣(20200204)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
