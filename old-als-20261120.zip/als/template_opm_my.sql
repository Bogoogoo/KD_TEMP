-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.template_opm_my 結構
DROP TABLE IF EXISTS `template_opm_my`;
CREATE TABLE IF NOT EXISTS `template_opm_my` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '客戶名稱',
  `customer_credit` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '信用額度',
  `customer_id` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '客戶編號',
  `condition_code` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '付款條件說明',
  `performance_area` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '業績區域',
  `seller` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `visit_date` timestamp NULL DEFAULT NULL COMMENT '最近參訪日期',
  `department` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '銷售部門',
  `level2` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '大區域名稱',
  `level3` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '中區域名稱',
  `visit` int DEFAULT NULL COMMENT '參訪明細',
  `visit_place` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '最近參訪展館',
  `customer_group` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '類別',
  `all_amount` int DEFAULT NULL COMMENT '累計銷貨',
  `year` int DEFAULT NULL COMMENT '銷貨(今年)',
  `year1` int DEFAULT NULL COMMENT '銷貨(去年)',
  `year2` int DEFAULT NULL COMMENT '銷貨(前年)',
  `year3` int DEFAULT NULL COMMENT '銷貨(大前年)',
  `year4` int DEFAULT NULL COMMENT '銷貨(大大前年)',
  `year5` int DEFAULT NULL COMMENT '銷貨(大大大前年)',
  `month1` int DEFAULT NULL COMMENT '1月(今年)',
  `month2` int DEFAULT NULL COMMENT '1月(今年)',
  `month3` int DEFAULT NULL COMMENT '3月(今年)',
  `month4` int DEFAULT NULL COMMENT '4月(今年)',
  `month5` int DEFAULT NULL COMMENT '5月(今年)',
  `month6` int DEFAULT NULL COMMENT '6月(今年)',
  `month7` int DEFAULT NULL COMMENT '7月(今年)',
  `month8` int DEFAULT NULL COMMENT '8月(今年)',
  `month9` int DEFAULT NULL COMMENT '9月(今年)',
  `month10` int DEFAULT NULL COMMENT '10月(今年)',
  `month11` int DEFAULT NULL COMMENT '11月(今年)',
  `month12` int DEFAULT NULL COMMENT '12月(今年)',
  `t_month` int DEFAULT NULL COMMENT '交易月份數(今年)',
  `t_month1` int DEFAULT NULL COMMENT '交易月份數(去年)',
  `t_month2` int DEFAULT NULL COMMENT '交易月份數(前年)',
  `t_month3` int DEFAULT NULL COMMENT '交易月份數(大前年)',
  `t_month4` int DEFAULT NULL COMMENT '交易月份數(大大前年)',
  `k3_number` decimal(9,2) NOT NULL COMMENT '數量(K3)',
  `k3_account` int DEFAULT NULL COMMENT '金額(K3)',
  `k6_number` decimal(9,2) NOT NULL COMMENT '數量(K6)',
  `k6_account` int DEFAULT NULL COMMENT '金額(K6)',
  `pp_number` decimal(9,2) NOT NULL COMMENT '數量(PP)',
  `pp_account` int DEFAULT NULL COMMENT '金額(PP)',
  `cabinet_number` decimal(9,2) NOT NULL COMMENT '數量(cabinet)',
  `cabinet_account` int DEFAULT NULL COMMENT '金額(cabinet)',
  `salesperson` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '業務員',
  `istrade` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '已交易',
  `reach` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '交易達20萬',
  `k3_percent` decimal(9,4) NOT NULL COMMENT '銷貨比(K3)',
  `k6_percent` decimal(9,4) NOT NULL COMMENT '銷貨比(K6)',
  `pp_percent` decimal(9,4) NOT NULL COMMENT '銷貨比(PP)',
  `cabinet_percent` decimal(9,4) NOT NULL COMMENT '銷貨比(cabinet)',
  `grow` decimal(9,4) DEFAULT NULL COMMENT '較去年成長(今年)',
  `grow1` decimal(9,4) DEFAULT NULL COMMENT '較去年成長(去年)',
  `grow2` decimal(9,4) DEFAULT NULL COMMENT '較去年成長(前年)',
  `grow3` decimal(9,4) DEFAULT NULL COMMENT '較去年成長(大前年)',
  `grow4` decimal(9,4) DEFAULT NULL COMMENT '較去年成長(大大前年)',
  `grow_money` int DEFAULT NULL COMMENT '較去年成長金額(今年)',
  `grow_money1` int DEFAULT NULL COMMENT '較去年成長金額(去年)',
  `grow_money2` int DEFAULT NULL COMMENT '較去年成長金額(前年)',
  `grow_money3` int DEFAULT NULL COMMENT '較去年成長金額(大前年)',
  `grow_money4` int DEFAULT NULL COMMENT '較去年成長金額(大大前年)',
  `rank` int DEFAULT NULL COMMENT '排名(今年)',
  `rank1` int DEFAULT NULL COMMENT '排名(去年)',
  `rank2` int DEFAULT NULL COMMENT '排名(前年)',
  `rank3` int DEFAULT NULL COMMENT '排名(大前年)',
  `rank4` int DEFAULT NULL COMMENT '排名(大大前年)',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '建立時間',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=906 DEFAULT CHARSET=utf8 COMMENT='OPM報表(馬來西亞)-結果資料';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
