-- --------------------------------------------------------
-- 主機:                           192.168.1.79
-- 伺服器版本:                        8.0.20 - MySQL Community Server - GPL
-- 伺服器作業系統:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 傾印  資料表 als.als_list_level_extra 結構
DROP TABLE IF EXISTS `als_list_level_extra`;
CREATE TABLE IF NOT EXISTS `als_list_level_extra` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `list` int NOT NULL COMMENT '列表',
  `list_fun` int NOT NULL COMMENT '列表功能',
  `user_id` int NOT NULL COMMENT '使用者id',
  `s_date` date NOT NULL COMMENT '啟動時間',
  `e_date` date DEFAULT NULL COMMENT '關閉時間',
  `start_up` int DEFAULT '0' COMMENT '是否啟動/1=啟動',
  `permanent` int NOT NULL DEFAULT '0' COMMENT '永久權限/1=永久',
  `allocation` int NOT NULL COMMENT '填寫人',
  `del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '刪除',
  PRIMARY KEY (`id`),
  KEY `list` (`list`)
) ENGINE=InnoDB AUTO_INCREMENT=3465 DEFAULT CHARSET=utf8 COMMENT='額外權限管理(20191211)';

-- 取消選取資料匯出。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
